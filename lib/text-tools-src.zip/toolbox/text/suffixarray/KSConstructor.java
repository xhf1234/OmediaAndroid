package toolbox.text.suffixarray;

import java.util.Arrays;

/**
 *  KS Constructo algorithm for suffix array
 * 
 * it will take O(n) time , O(n) space
 * 
 * (1)for large text(>50M) 
 *     i am not sure  how much extra space the algoritm actually occupy, but should be a lot of overhead
 ×   you can use other  O(nlogn) time O(n/logn) space algorithm or algorithm using extend disk
 * (2) for small text (<10k), but big Alphabet Size( 64k)
 *     however the complexity of the algorithm is relavate to the Alphabet Size
 *     I have do some optimization(convert the charater into lexicographic name), it can help
 *     but you may need other O(nlogn) time algorithm for too small text,but big alphabet size 
 * (3) becareful the input!!!!!!!!   
 * 	   To implement the algorithm eaiser
 *     - getSuffixArray(String text, SuffixArray output) 
 * 	    you should give the suffix array with (size+3) , size is the text size 
 * 	   -  getSuffixArray(char[] text, int textSize, SuffixArray output)
 * 	    you should give the text with (size+3), three zero padding in the end, size is the actual text size 
 * 	    you should give the suffix array with (size+3) , size is the actual text size 
 *     	
 * 	
 * For more information see
 *		- Simple linear work suffix array construction by J. Karkkainen and P. Sanders(2002) 
 *		－Efficient Implementations of Suffix Array Construction Algorithms Sunglim Lee  and Kunsoo Park(2004)
 *
 *	refactor from C++ code in the KP02, modification to save memory in SK04
 *  
 * @author Mingjiang Ye (yemingjiang@rd.netease.com).
 * 
 * Copyright (c) 2006, Outfox Team
 */

public class KSConstructor implements ISuffixArrayConstructor {

	
	public static final int MAX_INTERNAL_BUF_SIZE = 1024 * 1024;
	
	public static final int ZERO_PADDING_SIZE = 3;

	public static final int MIN_CONTENT_LENGTH = 5;

	public static final int OPTIMIZE_TEXT_SIZE = 64 * 1024;

	// default size is 16k;
	public final static int DEFAULT_INIT_BUF_SIZE = 16 * 1024;

	// init a block of memory
	protected char[] contentBuf = new char[DEFAULT_INIT_BUF_SIZE];

	/**
	 *  construct the suffix array
	 *  
	 * @param text the text to be construct  suffix array,
	 * @param suffixArray the ouput suffix array,  the size of ouput must >=text.length +3 
	 * 
	 * @return successful or not
	 *  */
	public boolean getSuffixArray(String text, int[] suffixArray) {

		int actualSize = text.length() + ZERO_PADDING_SIZE;
		if (contentBuf == null || contentBuf.length < actualSize)
			contentBuf = new char[actualSize];
		text.getChars(0, text.length(), contentBuf, 0);
		for (int i = text.length(); i < actualSize; i++)
			contentBuf[i] = 0;

		return getSuffixArray(contentBuf, text.length(), suffixArray);
	}

	/**
	 *  construct the suffix array
	 *  
	 * @param text the text to be construct  suffix array, only part of [0, textSize)
	 * 				the text true length must >= textSize+3
	 * 				and the  text[textSize],text[textSize+1],text[textSize+2] must be zero
	 * @param textSize the size of the text to be construct  suffix array,
	 * @param suffixArray the ouput suffix array,  the size of ouput must >= textSize +3 
	 *
	 * @return successful or not
	 *  */
	public boolean getSuffixArray(char[] text, int textSize, int[] suffixArray) {
		int actualSize = textSize + ZERO_PADDING_SIZE;

		// the output size must bigger than text.length+3
		if (text.length < actualSize || suffixArray == null
				|| suffixArray.length < actualSize)
			return false;

		// must be three zero padding in the end of the buffer
		for (int i = textSize; i < actualSize; i++)
			if (text[i] != 0)
				return false;

		// no optimize if the text too big
		if (textSize > OPTIMIZE_TEXT_SIZE)
			suffixArray(text, suffixArray, textSize, Character.MAX_VALUE);
		else {
			//here is a hook ,notice that the text may be the contentBuf
			// if called by getSuffixArray(String text, SuffixArray output)
			// it can save the memory but be careful
			if (contentBuf == null || contentBuf.length < actualSize)
				contentBuf = new char[actualSize];
			// allocat a new contentBuf to store the content if need
			int maxLexiName = convertToLexicArray(text, textSize, contentBuf);
			if (maxLexiName < 0)
			{
				if ( contentBuf.length > MAX_INTERNAL_BUF_SIZE )
					contentBuf = new char[DEFAULT_INIT_BUF_SIZE];
				return false;
			}
			suffixArray(contentBuf, suffixArray, textSize, maxLexiName);
		}
		// to release the memory
		if ( contentBuf.length > MAX_INTERNAL_BUF_SIZE )
			contentBuf = new char[DEFAULT_INIT_BUF_SIZE];
		return true;
	}

	protected static final int THIRD_INDEX_RATION = 1000;

	protected static final int THIRD_INDEX_NUMBER = 1 + Character.MAX_VALUE
			/ THIRD_INDEX_RATION;

	protected int[] thirdIndex = new int[THIRD_INDEX_NUMBER];

	protected static final int SECOND_INDEX_RATION = 100;

	protected static final int SECOND_INDEX_NUMBER = THIRD_INDEX_NUMBER
			* THIRD_INDEX_RATION / SECOND_INDEX_RATION;

	protected int[] secondIndex = new int[SECOND_INDEX_NUMBER];

	protected static final int FIRST_INDEX_NUMBER = SECOND_INDEX_NUMBER
			* SECOND_INDEX_RATION;

	protected int[] charLexicName = new int[FIRST_INDEX_NUMBER];

	/**
	 * 
	 *  convert the character of the  string into the lexicographic name array
	 * 
	 *  @return   the maxium lexicographic name of the content
	 *  		  if <0 means failed
	 *  
	 */
	protected int convertToLexicArray(char[] orgTxt, int textSize, char[] buf) {
		Arrays.fill(charLexicName, 0, FIRST_INDEX_NUMBER, 0);
		Arrays.fill(secondIndex, 0, SECOND_INDEX_NUMBER, 0);
		Arrays.fill(thirdIndex, 0, THIRD_INDEX_NUMBER, 0);
		for (int i = 0; i < textSize; i++) {
			int index = orgTxt[i];
			charLexicName[index] = 1;
			secondIndex[index / SECOND_INDEX_RATION] = 1;
			thirdIndex[index / THIRD_INDEX_RATION] = 1;
		}

		/* character equals zero exist , illagal */
		if (charLexicName[0] == 1)
			return -1;

		/* number the character from 1 */
		int lexiName = 0;
		int thirdBase = 0, secondBase = 0;
		for (int i = 0; i < THIRD_INDEX_NUMBER; i++) {
			if (thirdIndex[i] == 1) {
				int tempOff = 10 * i;
				for (int j = 0; j < 10; j++) {
					if (secondIndex[tempOff + j] == 1) {
						int offset = thirdBase + secondBase;
						for (int k = 0; k < 100; k++) {
							if (charLexicName[offset + k] == 1) {
								lexiName++;
								charLexicName[offset + k] = lexiName;
							}
						}
					}
					secondBase += SECOND_INDEX_RATION;
				}
			}
			secondBase = 0;
			thirdBase += THIRD_INDEX_RATION;
		}

		/* convert the string to character range */
		for (int i = 0; i < textSize; i++) {
			int index = orgTxt[i];
			buf[i] = (char) charLexicName[index];
		}

		for (int i = textSize; i < textSize + 3; i++)
			buf[i] = 0;

		return lexiName;
	}

	// compare <a1,a2> < b1,b2>
	protected boolean leq(int a1, int a2, int b1, int b2) {
		return (a1 < b1 || a1 == b1 && a2 <= b2);
	}

	// compare <a1,a2, a3> < b1,b2,b3>
	protected boolean leq(int a1, int a2, int a3, int b1, int b2, int b3) {
		return (a1 < b1 || a1 == b1 && leq(a2, a3, b2, b3));
	}

	// radix pass short
	protected void radixPass(int[] a, int[] b, int[] r, int offset, int n, int K, int[] c) {
		// count occurrences
		for (int i = 0; i <= K; i++)
			c[i] = 0;
		// reset counters
		for (int i = 0; i < n; i++)
			c[r[offset + a[i]]]++;
		// count occurences
		for (int i = 0, sum = 0; i <= K; i++) { // exclusive prefix sums
			int t = c[i];
			c[i] = sum;
			sum += t;
		}
		for (int i = 0; i < n; i++)
			b[c[r[offset + a[i]]]++] = a[i]; // sort
	}

	protected void radixPass(int[] a, int[] b, char[] r, int offset, int n,
			int K , int[] c) {
		// count occurrences
		for (int i = 0; i <= K; i++)
			c[i] = 0;
		// reset counters
		for (int i = 0; i < n; i++)
			c[r[offset + a[i]]]++;
		// count occurences
		for (int i = 0, sum = 0; i <= K; i++) { // exclusive prefix sums
			int t = c[i];
			c[i] = sum;
			sum += t;
		}
		for (int i = 0; i < n; i++)
			b[c[r[offset + a[i]]]++] = a[i]; // sort
	}

	// find the suffix array SA of s[0..n-1] in {1..K}^n
	// require s[n]=s[n+1]=s[n+2]=0, n>=2
	protected void suffixArray(int[] s, int[] SA, int n, int K) {
		int n0 = (n + 2) / 3;
		int n1 = (n + 1) / 3;
		int n2 = n / 3;
		int n02 = n0 + n2;
		int[] s12 = new int[n02 + 3];
		s12[n02] = s12[n02 + 1] = s12[n02 + 2] = 0;
		int[] SA12 = new int[n02 + 3];
		SA12[n02] = SA12[n02 + 1] = SA12[n02 + 2] = 0;
		int[] s0 = new int[n0];
		int[] SA0 = new int[n0];

		// generate positions of mod 1 and mod 2 suffixes
		// the "+(n0-n1)" adds a dummy mod 1 suffix if n%3 == 1
		for (int i = 0, j = 0; i < n + (n0 - n1); i++)
			if (i % 3 != 0)
				s12[j++] = i;

		// lsb radix sort the mod 1 and mod 2 triples
		
		//reusing SA
		radixPass(s12, SA12, s, 2, n02, K, SA);
		radixPass(SA12, s12, s, 1, n02, K, SA);
		radixPass(s12, SA12, s, 0, n02, K, SA);

		// find lexicographic names of triples
		int name = 0, c0 = -1, c1 = -1, c2 = -1;
		for (int i = 0; i < n02; i++) {
			if (s[SA12[i]] != c0 || s[SA12[i] + 1] != c1
					|| s[SA12[i] + 2] != c2) {
				name++;
				c0 = s[SA12[i]];
				c1 = s[SA12[i] + 1];
				c2 = s[SA12[i] + 2];
			}
			if (SA12[i] % 3 == 1) {
				s12[SA12[i] / 3] = name;
			} // left half
			else {
				s12[SA12[i] / 3 + n0] = name;
			} // right half
		}

		// recurse if names are not yet unique
		if (name < n02) {
			suffixArray(s12, SA12, n02, name);
			// store unique names in s12 using the suffix array
			for (int i = 0; i < n02; i++)
				s12[SA12[i]] = i + 1;
		} else
			// generate the suffix array of s12 directly
			for (int i = 0; i < n02; i++)
				SA12[s12[i] - 1] = i;

		// stably sort the mod 0 suffixes from SA12 by their first character
		for (int i = 0, j = 0; i < n02; i++)
			if (SA12[i] < n0)
				s0[j++] = 3 * SA12[i];
		//reusing SA
		radixPass(s0, SA0, s, 0, n0, K , SA);

		// merge sorted SA0 suffixes and sorted SA12 suffixes
		for (int p = 0, t = n0 - n1, k = 0; k < n; k++) {
			// pos of current offset 12 suffix
			int i = (SA12[t] < n0 ? SA12[t] * 3 + 1 : (SA12[t] - n0) * 3 + 2);
			// pos of current offset 0 suffix
			int j = SA0[p];
			// suffix from SA  is smaller
			if (SA12[t] < n0 ? leq(s[i], s12[SA12[t] + n0], s[j], s12[j / 3])
					: leq(s[i], s[i + 1], s12[SA12[t] - n0 + 1], s[j],
							s[j + 1], s12[j / 3 + n0])) {
				SA[k] = i;
				t++;
				if (t == n02) { // done --- only SA0 suffixes left
					for (k++; p < n0; p++, k++)
						SA[k] = SA0[p];
				}
			} else {
				SA[k] = j;
				p++;
				if (p == n0) { // done --- only SA12 suffixes left
					for (k++; t < n02; t++, k++)
						SA[k] = (SA12[t] < n0 ? SA12[t] * 3 + 1
								: (SA12[t] - n0) * 3 + 2);
				}
			}
		}
	}

	// find the suffix array SA of s[0..n-1] in {1..K}^n
	// require s[n]=s[n+1]=s[n+2]=0, n>=2
	protected void suffixArray(char[] s, int[] SA, int n, int K) {
		int n0 = (n + 2) / 3;
		int n1 = (n + 1) / 3;
		int n2 = n / 3;
		int n02 = n0 + n2;
		int[] s12 = new int[n02 + 3];
		s12[n02] = s12[n02 + 1] = s12[n02 + 2] = 0;
		int[] SA12 = new int[n02 + 3];
		SA12[n02] = SA12[n02 + 1] = SA12[n02 + 2] = 0;
		int[] s0 = new int[n0];
		int[] SA0 = new int[n0];

		// generate positions of mod 1 and mod 2 suffixes
		// the "+(n0-n1)" adds a dummy mod 1 suffix if n%3 == 1
		for (int i = 0, j = 0; i < n + (n0 - n1); i++)
			if (i % 3 != 0)
				s12[j++] = i;

		// lsb radix sort the mod 1 and mod 2 triples
		radixPass(s12, SA12, s, 2, n02, K, SA);
		radixPass(SA12, s12, s, 1, n02, K, SA);
		radixPass(s12, SA12, s, 0, n02, K, SA);

		// find lexicographic names of triples
		int name = 0, c0 = -1, c1 = -1, c2 = -1;
		for (int i = 0; i < n02; i++) {
			if (s[SA12[i]] != c0 || s[SA12[i] + 1] != c1
					|| s[SA12[i] + 2] != c2) {
				name++;
				c0 = s[SA12[i]];
				c1 = s[SA12[i] + 1];
				c2 = s[SA12[i] + 2];
			}
			if (SA12[i] % 3 == 1) {
				s12[SA12[i] / 3] = name;
			} // left half
			else {
				s12[SA12[i] / 3 + n0] = name;
			} // right half
		}

		// recurse if names are not yet unique
		if (name < n02) {
			suffixArray(s12, SA12, n02, name);
			// store unique names in s12 using the suffix array
			for (int i = 0; i < n02; i++)
				s12[SA12[i]] = i + 1;
		} else
			// generate the suffix array of s12 directly
			for (int i = 0; i < n02; i++)
				SA12[s12[i] - 1] = i;

		// stably sort the mod 0 suffixes from SA12 by their first character
		for (int i = 0, j = 0; i < n02; i++)
			if (SA12[i] < n0)
				s0[j++] = 3 * SA12[i];
		radixPass(s0, SA0, s, 0, n0, K, SA);

		// merge sorted SA0 suffixes and sorted SA12 suffixes
		for (int p = 0, t = n0 - n1, k = 0; k < n; k++) {
			// pos of current offset 12 suffix
			int i = (SA12[t] < n0 ? SA12[t] * 3 + 1 : (SA12[t] - n0) * 3 + 2);
			// pos of current offset 0 suffix
			int j = SA0[p];
			// suffix from SA  is smaller
			if (SA12[t] < n0 ? leq(s[i], s12[SA12[t] + n0], s[j], s12[j / 3])
					: leq(s[i], s[i + 1], s12[SA12[t] - n0 + 1], s[j],
							s[j + 1], s12[j / 3 + n0])) {
				SA[k] = i;
				t++;
				if (t == n02) { // done --- only SA0 suffixes left
					for (k++; p < n0; p++, k++)
						SA[k] = SA0[p];
				}
			} else {
				SA[k] = j;
				p++;
				if (p == n0) { // done --- only SA12 suffixes left
					for (k++; t < n02; t++, k++)
						SA[k] = (SA12[t] < n0 ? SA12[t] * 3 + 1
								: (SA12[t] - n0) * 3 + 2);
				}
			}
		}
	}

	public static void main(String args[]) throws Exception {
		KSConstructor skew = new KSConstructor();
		int[] sa = new int[100];
		String text = "mississippi";

		char[] temp = new char[text.length() + 20];
		text.getChars(0, text.length(), temp, 0);
		System.out.println(skew.getSuffixArray(text, sa));
		for (int i = 0; i < text.length(); i++)
			System.out.println(text.substring(sa[i]));

		System.out.println();
		System.out.println(skew.getSuffixArray(temp, text.length(), sa));
		for (int i = 0; i < text.length(); i++)
			System.out.println(text.substring(sa[i]));

	}

}
