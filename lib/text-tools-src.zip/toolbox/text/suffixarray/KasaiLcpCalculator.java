package toolbox.text.suffixarray;

/**
 * Kasai LCP algorithm for lcp calculater
 * 
 * it will take O(n) time , but 4n temporarily space in calculation n is the
 * number of character in text, the size of lcp array is 4n also
 * 
 * For more information see 
 * - Linear-time longestcommon- prefix computation in suffix arrays and its applications
 *  		by T. Kasai, G. Lee, H. Arimura, S.Arikawa, and K. Park.(CPM01)
 * 
 * refactor from C++ code in the paper
 * 
 * @author Mingjiang Ye (yemingjiang@rd.netease.com).
 * 
 * Copyright (c) 2006, Outfox Team
 */

public class KasaiLcpCalculator implements ILcpCalculator {

	public static final int MAX_INTERNAL_BUF_SIZE = 1024 * 1024;
	
	// default size is 16k;
	public final static int DEFAULT_INIT_BUF_SIZE = 16 * 1024;

	// init malloc a buffer
	protected int[] rank = new int[DEFAULT_INIT_BUF_SIZE];

	/**
	 *  return the result in given SuffixArray
	 *  @param text string to be construct suffix array
	 *  @param sa the suffix array of the text
	 *  @param lcp lcp Array to store the result
	 * 
	 *  @return successful or not
	 *  */
	public boolean getLcpArray(String text, int[] sa, int[] lcp) {
		// init rank array
		char[] content = text.toCharArray();
		return getLcpArray(content, sa, text.length(), lcp);
	}

	/**
	 *  return the result in given SuffixArray
	 *  @param text string to be construct suffix array
	 *  @param sa the suffix array of the text
	 *  @param size the size of the text and suffix array
	 *  @param lcp lcp Array to store the result
	 * 
	 *  @return successful or not
	 *  */
	public boolean getLcpArray(char[] text, int[] sa, int size, int[] lcp) {

		// init rank array
		if (rank.length < size)
			rank = new int[size];

		for (int i = 0; i < size; i++)
			rank[sa[i]] = i;
		// caculate the lcp array
		int h = 0, k = 0, j = 0;
		for (int i = 0; i < size; i++) {
			k = rank[i];
			if (k > 0) {
				j = sa[k - 1];
				while (i + h < size && j + h < size
						&& text[i + h] == text[j + h])
					h++;
				lcp[k] = h;
			} else
				// k== 0
				lcp[k] = -1;

			if (h > 0)
				h--;
		}
		
		//release the buffer
		if ( rank.length > MAX_INTERNAL_BUF_SIZE )
			rank = new int[DEFAULT_INIT_BUF_SIZE];
		return true;
	}

	public static void main(String args[]) throws Exception {
		// run the constructor
		KSConstructor skew = new KSConstructor();
		int[] sa = new int[100];
		String text = "12121212";
		char[] temp = new char[text.length() + 20];
		text.getChars(0, text.length(), temp, 0);
		System.out.println(skew.getSuffixArray(temp, text.length(), sa));
		for (int i = 0; i < text.length(); i++)
			System.out.println(text.substring(sa[i]));

		//run the lcp caculator
		KasaiLcpCalculator kasai = new KasaiLcpCalculator();
		int[] lcp = new int[100];
		kasai.getLcpArray(temp, sa, text.length(), lcp);
		for (int i = 0; i < text.length(); i++)
			System.out.print(lcp[i] + "\t");
	}

}
