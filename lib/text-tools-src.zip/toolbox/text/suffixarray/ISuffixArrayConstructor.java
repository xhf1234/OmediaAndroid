package toolbox.text.suffixarray;

/**
 * the interface of the suffix array constructor , suffix array is the an ordered
 * array of the suffixes of the input string
 * 
 * input the original text, output the suffix array
 * 
 * @author Mingjiang Ye (yemingjiang@rd.netease.com).
 * 
 * Copyright (c) 2006, Outfox Team
 */

public interface ISuffixArrayConstructor {

	/**
	 * consturct the suffxi array for the input text
	 * 
	 * @param text string to be construct suffix array
	 * @param suffixArray return the result in this array
	 * 
	 * @return succeful or not
	 */
	public boolean getSuffixArray(String text, int[] suffixArray);

	/**
	 * consturct the suffxi array for the input text
	 * 
	 * @param text char array to be construct suffix array, only [0,size) part
	 * @param textSize how much content of text will used to construct the suffix array
	 * @param suffixArray return the result in this array
	 * 
	 * @return succeful or not
	 */
	public boolean getSuffixArray(char[] text, int textSize, int[] suffixArray);

}
