package toolbox.text.suffixarray;

import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;

/**
 * evaluator the performance of each pattern search algorithm
 * only for this toolbox developer 
 *
 * @author Mingjiang Ye (yemingjiang@rd.netease.com).
 * 
 * Copyright (c) 2006, Outfox Team
 */
public class PerformanceEvaluator {

	public static byte[] getFileContent(File file) {
		FileInputStream in;
		byte[] content = null;
		try {
			in = new FileInputStream(file);
			content = new byte[(int) file.length()];
			int len = in.read(content);
			assert len == file.length();
			in.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return content;
	}

	protected String readText(File dir) throws UnsupportedEncodingException {
		FileFilter filter = new FileFilter() {
			public boolean accept(File file) {
				if (file.getName().toLowerCase().endsWith("parsed"))
					return true;
				return false;
			}
		};
		File[] textFiles = dir.listFiles(filter);

		StringBuilder builder = new StringBuilder();
		for (int i = 0; i < textFiles.length; i++) {
			byte[] content = getFileContent(textFiles[i]);
			String temp = new String(content, "utf8");
			builder.append(temp);
		}
		return builder.toString();
	}
	

	
	public void run() throws IOException {
		String text = readText(new File("./dataset"));
		System.out.println(" total text size is" + text.length() + " characters");

		ISuffixArrayConstructor ks = SuffixArrayFactory.createConstructor(SuffixArrayFactory.KS_SUFFIXARRAY_ALGORLTHM);
		ILcpCalculator kasai = SuffixArrayFactory.createLcpAlg(SuffixArrayFactory.KASAI_LCP_ALGORLTHM);
		ILcpCalculator manzini = SuffixArrayFactory.createLcpAlg(SuffixArrayFactory.MANZINI_LCP_ALGORLTHM);
	
		
		final int MAX_TEXT_SIZE= 1024*1024;
		int maxSize = text.length()< MAX_TEXT_SIZE? text.length():MAX_TEXT_SIZE; 
		int i = 0;
	
		int[] sa = new int[MAX_TEXT_SIZE+3];
		int[] lcp = new int[MAX_TEXT_SIZE];
		char[] testText = new char[MAX_TEXT_SIZE+3];
		for ( int testSize  = 32; testSize<=maxSize; testSize = testSize*2 )
		{
			int round = 32;
			
			if (testSize  >= 1024)
			{
				i++;
				round = round/ i;
			}
			else if (testSize  >= 32*1024)
			{
				i = i*2+1;
				round = round/ i;
				if (round < 1)
					round = 1;
			}
			text.getChars(0, testSize, testText, 0);
			testText[testSize] = testText[testSize+1] = testText[testSize+2] = 0; 
	
			System.out.print("KS ALG:"); 
			runConstructorTest(ks, testText ,testSize, sa, round);
			
			System.out.print("kasai ALG:"); 
			ks.getSuffixArray(testText, testSize,sa);
			runLCPTest(kasai, testText,sa ,testSize,lcp, round);
		
			System.out.print("manzini ALG:"); 
			ks.getSuffixArray(testText,testSize, sa);
			runLCPTest(manzini,testText, sa ,testSize, lcp, round);
			
		}	
	}

	public void run2() throws IOException {
		String text = readText(new File("./dataset"));
		System.out.println(" total text size is" + text.length() + " characters");

		ISuffixArrayConstructor ks = SuffixArrayFactory.createConstructor(SuffixArrayFactory.KS_SUFFIXARRAY_ALGORLTHM);
		ILcpCalculator kasai = SuffixArrayFactory.createLcpAlg(SuffixArrayFactory.KASAI_LCP_ALGORLTHM);
		ILcpCalculator manzini = SuffixArrayFactory.createLcpAlg(SuffixArrayFactory.MANZINI_LCP_ALGORLTHM);
	
		int MAX_TEXT_SIZE = 10*1024*1024;
		int[] sa = new int[MAX_TEXT_SIZE+3];
		int[] lcp = new int[MAX_TEXT_SIZE];
		char[] testText = new char[MAX_TEXT_SIZE+3];
		int testSize = MAX_TEXT_SIZE;
		int pos = 0;
		while (pos < MAX_TEXT_SIZE)
		{
			int len = (pos +  text.length()) < MAX_TEXT_SIZE? text.length():(MAX_TEXT_SIZE-pos);
			text.getChars(0, len, testText, pos);
			pos += len;
		}
		testText[MAX_TEXT_SIZE] =testText[MAX_TEXT_SIZE+1] = testText[MAX_TEXT_SIZE+2] = 0;
	
		System.out.print("KS ALG:");
		runConstructorTest(ks, testText ,testSize, sa, 1);
		
		System.out.print("kasai ALG:"); 
		ks.getSuffixArray(testText, testSize,sa);
		runLCPTest(kasai, testText,sa ,testSize,lcp, 1);
	
		System.out.print("manzini ALG:"); 
		ks.getSuffixArray(testText,testSize, sa);
		runLCPTest(manzini,testText, sa ,testSize, lcp, 1);
	}
	protected void runConstructorTest(ISuffixArrayConstructor constructor,char[] text, int size ,int[]sa, int round) {
		long start = System.currentTimeMillis();
		for ( int i =0 ; i < round; i++)
			constructor.getSuffixArray(text,size, sa);
		long time = System.currentTimeMillis() - start;
		float speed = round * size*1.0f / time;
	/*	System.out.println("text.length is:" + text.length() + ", time is :"
			+ time + " msec," + "speed is: " + speed + " k char/sec"); */
		System.out.println( size + "\t"+ time  + "\t"+ speed);
	}

	protected void runLCPTest(ILcpCalculator calculator,char[] text,  int [] sa, int size , int[] lcp, int round) {
		long start = System.currentTimeMillis();
		for ( int i =0 ; i < round; i++)
			calculator.getLcpArray(text,sa,size, lcp);
		long time = System.currentTimeMillis() - start;
		float speed = round * size*1.0f / time;
		/*	System.out.println("text.length is:" + text.length() + ", time is :"
		+ time + " msec," + "speed is: " + speed + " k char/sec"); */
		System.out.println( size + "\t"+ time  + "\t"+ speed);
	}

	public static void main(String args[]) throws Exception {

		PerformanceEvaluator evaluator = new PerformanceEvaluator();

		evaluator.run2();
	}

}
