package toolbox.text.patternsearch;

import java.util.Set;

/**
 * interface of the pattern search algorithm
 *
 * @author Mingjiang Ye (yemingjiang@rd.netease.com).
 *
 * Copyright (c) 2006, Outfox Team
 */

public interface IPatternSearcher {

    /**
     * some algorithm need pre-pocess before search 
     * since this step need the pattern libary
     * you should call this once before call the search function
     * 
     * @param words The String set to be match.
     * @param params The specific params for each algorithm
     * 
     * @return true of false
     */
    public boolean compile(Set<String> words, Object... params);

    /**
     * set a new match handler to the pattern search.
     * @param handler The IMatchHandler to be called when a match occur.
     * @return the old IMatchHandler, if doesn't have on ,return null
     */
    public IMatchHandler setHandler(final IMatchHandler handler);

    /**
     * get  current using  handler of the pattern search.
     * @return  return the current using IMatchHandler
     */
    public IMatchHandler getHandler();

    /**
     * search the text for the pattern set.
     * @param text The text to be searched.
     */
    public void search(String text);
}
