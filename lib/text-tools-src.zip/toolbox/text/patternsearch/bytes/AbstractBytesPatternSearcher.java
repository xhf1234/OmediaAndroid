package toolbox.text.patternsearch.bytes;


/**
 * Abstract class that defines a pattern searcher implements setHandler function
 * 
 * @author Mingjiang Ye (yemingjiang@rd.netease.com), David
 *
 * Copyright (c) 2006, Outfox Team
 */

public abstract class AbstractBytesPatternSearcher 
        implements IBytesPatternSearcher {

    protected IMatchHandler handler;

    /**
     * the defualt constructor
     */
    public AbstractBytesPatternSearcher() {}

    /**
     * set a new match handler to the pattern search.
     * 
     * @param handler
     *            The IMatchHandler to be called when a match occur.
     * @return the old IMatchHandler, if doesn't have on ,return null
     */
    public IMatchHandler setHandler(IMatchHandler handler) {
        IMatchHandler oldHandler = this.handler;
        this.handler = handler;
        return oldHandler;
    }

    /**
     * get current using handler of the pattern search.
     * 
     * @return return the current using IMatchHandler
     */
    public IMatchHandler getHandler() {
        return this.handler;
    }

}
