package toolbox.text.patternsearch.bytes;

import java.util.Set;

/**
 * The interface of a bytes pattern search algorithm
 *
 * @author Mingjiang Ye (yemingjiang@rd.netease.com), David
 *
 * Copyright (c) 2006, Outfox Team
 */

public interface IBytesPatternSearcher {
    /**
     * the interface of the handler which handles the match result in the input
     * string
     * 
     * @author Mingjiang Ye (yemingjiang@rd.netease.com).
     * 
     * Copyright (c) 2006, Outfox Team
     */
    public interface IMatchHandler {
        /**
         * Called by StringSearch upon a hit.
         * 
         * @param startIndex  the startindex of the hit
         * @param term  the term that was found
         * @return true the search will continue false the search will stopped
         */
        boolean foundAt(int startIndex, byte[] term);
    }
    /**
     * Makes the pre-processing to the words to be searched.
     * Some algorithm needs pre-pocessing before search. 
     * Since this step need the pattern libary you should call this once before 
     * call the search function
     * 
     * @param words The pattern set to be matched
     * @param params The specific params for each algorithm
     * 
     * @return true if success, false otherwise
     */
    public boolean compile(Set<byte[]> words, Object... params);
    /**
     * Sets the match handler to the pattern search. When a pattern is found,
     * handler.foundAt() is called.
     * 
     * @param handler  the IMatchHandler to be called when a match occurs
     * @return the old IMatchHandler, null if there isn't one
     */
    public IMatchHandler setHandler(final IMatchHandler handler);
    /**
     * Gets the current handler of the pattern search.
     * @return  return the current using IMatchHandler
     */
    public IMatchHandler getHandler();
    /**
     * Searchs the text for the pattern set.
     * @param text  the text to be searched
     */
    public void search(byte[] text);
}
