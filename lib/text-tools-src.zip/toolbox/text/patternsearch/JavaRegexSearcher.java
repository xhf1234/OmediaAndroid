package toolbox.text.patternsearch;

import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * a wrapper of java regex 
 * 
 * @author Mingjiang Ye (yemingjiang@rd.netease.com).
 * 
 * Copyright (c) 2006, Outfox Team
 */

public class JavaRegexSearcher extends AbstractPatternSearcher {

    protected Pattern myPatten;

    /**
     * pre-process the pattern set
     * 
     * @param words
     *            The String set to be match.
     * @param params
     *            the specific params for each algorithm
     * @return true of false
     */
    public boolean compile(Set<String> words, Object... params) {
        if (words.size() <= 0)
            return false;
        StringBuffer str = new StringBuffer();
        for (String word: words)
            str.append(str.length() > 0 ? "|" : "").append(
                    "(\\Q" + word + "\\E)");
        myPatten = Pattern.compile("(" + str.toString() + ")");
        return true;
    }

    /**
     * search the text for the pattern set.
     * 
     * @param text
     *            The text to be searched.
     */
    public void search(String text) {
        if (myPatten == null)
            return;
        Matcher matcher = myPatten.matcher(text);
        while (matcher.find()) {
            if (!handler.foundAt(matcher.start(), matcher.group()))
                return;
        }
    }
}
