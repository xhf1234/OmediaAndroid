package toolbox.text.patternsearch;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Hashtable;
import java.util.Set;

/**
 * Aho-Corasick text search algorithm implementation
 * 
 * NOTE: For more information visit -
 * http://www.cs.uku.fi/~kilpelai/BSA05/lectures/slides04.pdf
 * 
 * refeactor from C# code found in internet
 * 
 * note: when the one pattern A is substring of the other pattern B if ( A is
 * suffix of B) output is just B else output is A and B if you want only output
 * B, you should write an IMatchHandler to ommit it
 * 
 * (1)pattern: "abc" "bcd" text: "abcd" match: "abc" "bcd" (2) pattern: "in"
 * "ain" text: "main" match: only "ain" (3) pattern: "ai" "ain" "main" text:
 * "main" match: "ai" "main"
 * 
 * @author Mingjiang Ye (yemingjiang@rd.netease.com).
 * 
 * Copyright (c) 2006, Outfox Team
 */

public class AhoCorasickSearcher extends AbstractPatternSearcher {

    // / Root of keyword tree
    protected TreeNode _root;

    public AhoCorasickSearcher() {
        super();
    }

    /**
     * pre-process the pattern set
     * 
     * @param words
     *            The String set to be match.
     * @param params
     *            the specific params for each algorithm
     * @return true of false
     */
    public boolean compile(Set<String> words, Object... params) {
        if (words.size() <= 0)
            return false;

        BuildTree(words);
        return true;
    }

    /**
     * search the text for the pattern set.
     * 
     * @param text
     *            The text to be searched.
     */
    public void search(String text) {
        TreeNode ptr = _root;
        int index = 0;

        while (index < text.length()) {
            TreeNode trans = null;
            while (trans == null) {
                trans = ptr.getTransition(text.charAt(index));
                if (ptr == _root)
                    break;
                if (trans == null)
                    ptr = ptr.getFailure();
            }

            if (trans != null)
                ptr = trans;

            /*
             * for (String found : ptr.getResults()) { if (!
             * handler.foundAt(index - found.length() + 1, found)) return; }
             */

            // only match the longest
            String[] results = ptr.getResults();
            if (results.length > 0) {
                String found = results[0];
                if (!handler.foundAt(index - found.length() + 1, found))
                    return;
            }
            index++;
        }
    }

    /**
     * Build tree from specified keywords
     */
    protected void BuildTree(Set<String> words) {
        // Build keyword tree and transition function
        _root = new TreeNode(null, ' ');

        for (String pattern: words) {
            // add pattern to tree
            TreeNode nd = _root;
            for (int i = 0; i < pattern.length(); i++) {
                char c = pattern.charAt(i);
                TreeNode ndNew = null;
                for (TreeNode trans: nd.getTransitions()) {
                    if (trans.getChar() == c) {
                        ndNew = trans;
                        break;
                    }
                }
                if (ndNew == null) {
                    ndNew = new TreeNode(nd, c);
                    nd.addTransition(ndNew);
                }
                nd = ndNew;
            }
            nd.addResult(pattern);
        }

        // Find failure functions
        ArrayList<TreeNode> nodes = new ArrayList<TreeNode>();

        // level 1 nodes - fail to root node
        for (TreeNode nd: _root.getTransitions()) {
            nd.setFailure(_root);
            for (TreeNode trans: nd.getTransitions())
                nodes.add(trans);
        }
        // other nodes - using BFS
        while ((nodes.size() != 0)) {
            ArrayList<TreeNode> newNodes = new ArrayList<TreeNode>();
            for (TreeNode nd: nodes) {
                TreeNode r = nd.getParent().getFailure();
                char c = nd.getChar();

                while (r != null && !r.containsTransition(c))
                    r = r.getFailure();

                if (r == null)
                    nd.setFailure(_root);
                else {
                    nd.setFailure(r.getTransition(c));
                    for (String result: nd.getFailure().getResults())
                        nd.addResult(result);
                }

                // add child nodes to BFS list
                for (TreeNode child: nd.getTransitions())
                    newNodes.add(child);
            }
            nodes = newNodes;
        }
        _root.setFailure(_root);
    }

    /**
     * interal class of the node in ahocorasick tree
     */

    class TreeNode {

        protected char inputChar;

        protected TreeNode parent;

        protected TreeNode failure;

        protected TreeNode[] transitionsAr;

        protected ArrayList<String> results;

        protected String[] resultsAr;

        protected Hashtable<Character, TreeNode> transHash;

        protected Comparator<String> resultComparator = new StringLengthComparator();

        public TreeNode(TreeNode parent, char c) {
            this.inputChar = c;
            this.parent = parent;
            this.results = new ArrayList<String>();
            this.resultsAr = new String[0];
            this.transitionsAr = new TreeNode[0];
            this.transHash = new Hashtable<Character, TreeNode>();
        }

        // Adds pattern ending in this node
        public void addResult(String result) {
            if (results.contains(result))
                return;
            results.add(result);
            resultsAr = results.toArray(new String[results.size()]);
            // we will sort it by string length
            Arrays.sort(resultsAr, resultComparator);
        }

        // Adds trabsition node
        public void addTransition(TreeNode node) {
            transHash.put(node.getChar(), node);
            transitionsAr = new TreeNode[transHash.size()];
            System.arraycopy(transHash.values().toArray(), 0, transitionsAr, 0,
                    transHash.size());
        }

        public TreeNode getTransition(char c) {
            return (TreeNode) transHash.get(c);
        }

        public boolean containsTransition(char c) {
            return getTransition(c) != null;
        }

        public char getChar() {
            return inputChar;
        }

        public TreeNode getParent() {
            return parent;
        }

        public TreeNode getFailure() {
            return failure;
        }

        public void setFailure(TreeNode node) {
            this.failure = node;
        }

        public TreeNode[] getTransitions() {
            return transitionsAr;
        }

        public String[] getResults() {
            return resultsAr;
        }
    }

}
