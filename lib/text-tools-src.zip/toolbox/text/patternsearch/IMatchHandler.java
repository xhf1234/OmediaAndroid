package toolbox.text.patternsearch;

/**
 * the interface of the handler which handle the match result in the input
 * string
 * 
 * @author Mingjiang Ye (yemingjiang@rd.netease.com).
 * 
 * Copyright (c) 2006, Outfox Team
 */
public interface IMatchHandler {
    /**
     * Called by StringSearch upon a hit.
     * 
     * @param startIndex
     *            The startindex of the hit
     * @param term
     *            The term that was found
     * @return true the search will continue false the search will stopped
     */
    boolean foundAt(int startIndex, String term);
}
