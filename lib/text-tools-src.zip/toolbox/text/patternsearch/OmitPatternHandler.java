package toolbox.text.patternsearch;

/**
 * omit all the pattern match in the search text
 * for example ,if the pattern is "hello", text is "hello world", result is " world"
 * 
 * @author Mingjiang Ye (yemingjiang@rd.netease.com).
 * 
 * Copyright (c) 2006, Outfox Team
 */
public class OmitPatternHandler implements IMatchHandler {

    protected StringBuilder builder;

    protected boolean hitFlag = false;

    protected String searchText = null;

    protected int lastIndex = 0;

    public void setText(String text) {
        searchText = text;
        hitFlag = false;
        builder = null;
        lastIndex = 0;
    }

    /**
     * Called by StringSearch upon a hit.
     * 
     * @param startIndex
     *            The startindex of the hit
     * @param term
     *            The term that was found
     * @return true the search will continue false the search will stopped
     */
    public boolean foundAt(int startIndex, String term) {
        if ( startIndex >= lastIndex){
            if (builder == null)
                builder = new StringBuilder();
            builder.append(searchText.substring(lastIndex, startIndex));
            lastIndex = startIndex + term.length();
        }
        return true;
    }

    /**
     * @return the hit string , null if not hit
     */
    public String getOmittedStr() {
        // not hit
        if (builder == null)
            return searchText;

        if (lastIndex < searchText.length()) {
            builder
                    .append(searchText
                            .substring(lastIndex, searchText.length()));
            lastIndex = searchText.length();
        }
        return builder.toString();
    }
}
