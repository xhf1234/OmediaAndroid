package toolbox.text.patternsearch;

import java.util.HashMap;

/**
 * the factory of the pattern searcher algorithm
 * 
 * now only support (1) java regex (2) Aho-corasick, (3) WuManber
 * 
 * @author Mingjiang Ye (yemingjiang@rd.netease.com).
 * 
 * Copyright (c) 2006, Outfox Team
 */

public class PatternSearcherFactory {

    public static final String JAVA_REGEX_PATTERN_SEARCHER = "regex";

    public static final String WU_MANBER_SEARCHER = "wu-manber";

    public static final String AHO_CORASICK_SEARCHER = "aho-corasick";

    protected static HashMap<String, Class> searcherMap;

    static {
        searcherMap = new HashMap<String, Class>();
        searcherMap.put(JAVA_REGEX_PATTERN_SEARCHER, JavaRegexSearcher.class);
        searcherMap.put(AHO_CORASICK_SEARCHER, AhoCorasickSearcher.class);
        searcherMap.put(WU_MANBER_SEARCHER, WuManberSearcher.class);

    }

    /**
     * create the pattern searcher algorithm
     * 
     * @param name
     *            the name of the algorithm
     * @return the IPatternSearcher object
     */
    public static IPatternSearcher createPatternSearcher(String name) {
        Class clz = searcherMap.get(name);
        if (clz == null)
            return null;

        IPatternSearcher searcher;
        try {
            searcher = (IPatternSearcher) clz.newInstance();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            return null;
        }

        return searcher;
    }
}
