package toolbox.text.patternsearch;

import java.util.ArrayList;

/**
 * collect the Match result in the input string
 * 
 * @author Mingjiang Ye (yemingjiang@rd.netease.com).
 * 
 * Copyright (c) 2006, Outfox Team
 */
public class MatchCollectHandler implements IMatchHandler {

    protected ArrayList<MatchResult> resultList = new ArrayList<MatchResult>();

    /**
     * internal class of the match result with the matched term and the start
     * pos of the term in input string
     */
    public static class MatchResult {
        protected int start;

        protected String term;

        /**
         * @param startIndex
         *            the start pos of the matched term in input string
         * @param term
         *            the matched term in input string
         */
        public MatchResult(int startIndex, String term) {
            this.start = startIndex;
            this.term = term;
        }

        /**
         * @return the start pos of the matched term in input string
         */
        public int getStart() {
            return start;
        }

        /**
         * @return the matched term in input string
         */
        public String getMatchPattern() {
            return term;
        }

        @Override
        public String toString() {
            return "start:" + start + "," + "term:" + term;
        }

        @Override
        public boolean equals(Object obj) {
            MatchResult result = (MatchResult) obj;
            return (this.start == result.start)
                    && (this.term.equals(result.term));
        }
    }

    /**
     * Called by StringSearch upon a hit.
     * 
     * @param startIndex
     *            The startindex of the hit
     * @param term
     *            The term that was found
     * @return true the search will continue false the search will stopped
     */
    public boolean foundAt(int startIndex, String term) {
        resultList.add(new MatchResult(startIndex, term));
        return true;
    }

    /**
     * @return , the matched result of the input string
     */
    public MatchResult[] getMatchResults() {
        return resultList.toArray(new MatchResult[resultList.size()]);
    }

    /**
     * clear the matched result
     */
    public void clear() {
        resultList.clear();
    }
}
