package toolbox.text.textrank;

import java.util.HashMap;
import java.util.HashSet;

public class TextNode extends INode{

	//neighbours of the current node
	HashSet<String> neighbours;
	
	//corresponding weights for neighbours
	//the graph is a weighted graph, namely each edge should have a weight
	HashMap<String, Double> weights;
	
	//each node is assigned a score
	//the score will be calculated by PageRank Algorithm
	public double score = 1;
	
	/**
	 * Initialize a text node, specifying the id of the node
	 * @param label
	 */
	public TextNode(String label) {
		super(label);
		this.neighbours = new HashSet<String>();
		this.weights = new HashMap<String, Double>();
	}
	
	/**
	 * Add a neighbour to the current node, updating the weight
	 * @param id
	 * @param weight
	 */
	public void addNeighbour(String id, double weight){		
		this.neighbours.add(id);
		double original_weight = 0;		
		if (this.weights.get(id)!=null)
			original_weight = this.weights.get(id);				
		this.weights.put(id, original_weight + weight);
	}
	
	/**
	 * Get the degree of the current node
	 * @return the degree of the node
	 */
	public double getDegree(){
		return this.neighbours.size();
	}
	
	/**
	 * Get the id of the current node
	 * @return id
	 */
	public String getId(){
		return this.id;
	}
	
	/**
	 * Get the neighbours of the current node
	 * @return
	 */
	public HashSet<String> getNeighbours(){
		return this.neighbours;
	}
	
	/**
	 * Get weights of the neighbours
	 * @return
	 */
	public HashMap<String, Double> getWeights(){
		return this.weights;
	}
	
}
