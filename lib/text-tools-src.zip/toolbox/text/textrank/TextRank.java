package toolbox.text.textrank;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.ArrayList;
import java.util.Random;
import java.util.TreeMap;

public class TextRank {
	
	//The segmented words composing the original text
	List<String> textWords;
	
	//The graph constructed from text[]
	TextGraph graph;
	
	//Default value of d
	double parameter_d = 0.85;
	
	//Default value of convergent;
	double parameter_c = 10e-3;
	
	//Default number of neighbours
	int neighbours = 2;
	
	String[] rank_words;
	double[] rank_value;
	
	//The rank for each node
	TreeMap<Double, String> rankMap;
	TreeMap<Double, String> degreeMap;	
	
	public TextRank(){
		this.graph = new TextGraph();
		this.rankMap = new TreeMap<Double, String>();		
	}
	
	public TextRank(List<String> textWords){
		this.graph = new TextGraph();
		this.textWords = textWords;
		this.rankMap = new TreeMap<Double, String>();
	}
	
	public TextRank(double d, double c, int neighbour, List<String> words){		
		setPrameterD(d, c, neighbour);
		this.textWords = words;
		this.graph = new TextGraph();
		this.rankMap = new TreeMap<Double, String>();
		this.constructGraph(neighbours);
		this.calcPageRank();
		this.rank_words = new String[rankMap.keySet().size()];
		this.rank_value = new double[rankMap.keySet().size()];
		int index = rank_words.length -1;
		for (Double value:rankMap.keySet()){
			rank_value[index] 	= value;
			rank_words[index--] = rankMap.get(value); 
		}
	}
	
	public String[] getRankWords(){
		return this.rank_words;
	}
	
	public double[] getRankValue(){
		return this.rank_value;
	}
	
	//Set c and d for the algorithm
	public void setPrameterD(double d, double c, int neighbour){
		this.parameter_d = d;
		this.parameter_c = c;
		this.neighbours = neighbour;
	}
	
	public void setWords(List<String> textWords){
		this.textWords = textWords;
	}
	
	public void setGraph(TextGraph graph){
		this.graph = graph;
	}
	
	/**
	 * Contruct graph using 2-window	 
	 */
	public void constructGraph(){
		graph.addNode(textWords.get(0));
		for (int i = 1; i < textWords.size(); i++){
			graph.addNode(textWords.get(i));
			graph.addEdge(textWords.get(i-1), textWords.get(i));
		}
	}
	
	public void constructGraph(int n){
		for (int i = 0; i < n - 1; i++){
			graph.addNode(textWords.get(i));
		}
		
		for (int i = n - 1; i < textWords.size(); i++){
			graph.addNode(textWords.get(i));
			for (int j = 1; j < n; j++){
				graph.addEdge(textWords.get(i-j), textWords.get(i));
			}
		}
	}
	
	/**
	 * Calculate the page rank
	 */
	public void calcPageRank(){
		this.initialize();
		this.calcPageRankScore();
		this.sort();		
	}
	
	/**
	 * Initialize the graph
	 * The score of each node is set to be 1
	 */
	private void initialize(){
		//Initialize all the scores to be 1.
		for (String id:graph.id_node.keySet()){
			TextNode node = graph.id_node.get(id);
			node.score = 1;
			graph.id_node.put(id, node);
		}
	}
	
	/**
	 * Calculate page rank score for the nodes
	 */
	private void calcPageRankScore(){
		//Calculate the page rank recursively
		double difference = 0;
		do{
			difference = 0;
			for (String id:graph.id_node.keySet()){
				TextNode node = graph.id_node.get(id);
				HashSet<String> neighbours = node.getNeighbours();
				double sum = 0;
				for (String neighbour_id:neighbours){
					TextNode n_node = graph.id_node.get(neighbour_id);
					sum += n_node.score / n_node.getDegree();
				}
				double new_score = (1 - parameter_d) + parameter_d * sum; 
				difference += Math.abs(new_score - node.score);
				node.score = new_score;
				graph.id_node.put(id, node);
			}
		}while(difference < parameter_c );
	}
	
	public void calcDegreeRank(){
		this.degreeMap = new TreeMap<Double, String>();
		for (String id:graph.id_node.keySet()){
			TextNode node = graph.id_node.get(id);
			degreeMap.put(node.getNeighbours().size()+(new Random()).nextDouble()*1e-6, node.getId());
		}
	}
	
	public TreeMap<Double, String> getDegreeMap(){
		return this.degreeMap;
	}
	
	/**
	 * Sort the scores for each node
	 */
	private void sort(){
		// Initialize all the scores to be 1.
		for (String id:graph.id_node.keySet()){
			TextNode node = graph.id_node.get(id);			
			//The key value of TreeMap will be sorted automatically
			rankMap.put(
					node.score+(new Random()).nextDouble()*10e-6, 
					node.getId());
		}
	}
	
	public TreeMap<Double, String> getRank(){		
		return rankMap;
	}
	
	public void printGraph(){
		for (String id:graph.id_node.keySet()){
			TextNode node = graph.id_node.get(id);			
			HashSet<String> neighbours  = node.getNeighbours();
			HashMap<String, Double> weights = node.getWeights();
			System.out.print(node.getId()+":");
			for (String item:neighbours){
				System.out.print(item+"("+weights.get(item)+")"+",");
			}
			System.out.println();
		}
	}
	
	public XmlGraph getXmlGraph(){
		XmlGraph xmlGraph = graph.convert2XmlGraph();
		int rank = rankMap.size();
		HashMap<String, Integer> ranks = new HashMap<String, Integer>();
		for (Double key:rankMap.keySet()){
			ranks.put(rankMap.get(key), rank--);
		}
		for (int i = 0; i < xmlGraph.nodes.size(); i++){
			xmlGraph.ranks.add(ranks.get(xmlGraph.nodes.get(i)));
		}
		return xmlGraph;		
	}
	
	public static void main(String[] args){
		String[] words = new String[]{"This","is","an","algorihtm","which","is","very","similar","to","the","pagerank","algorithm"};
		List<String> list_words = new ArrayList<String>();
		for (String word:words){list_words.add(word);}
		TextRank ranker = new TextRank(0.85,10e-3,4,list_words);
		String[] rankWords = ranker.getRankWords();
		double[] rankValue = ranker.getRankValue();
		for (int i = 0; i < rankWords.length; i++){
			System.out.println(rankWords[i]+":"+rankValue[i]);					
		}
	}
}
