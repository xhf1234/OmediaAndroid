package toolbox.text.textrank;

import java.util.HashMap;
import java.util.HashSet;

public class TextGraph implements IGraph{
	
	public HashMap<String, TextNode> id_node;
	
	public TextGraph(){
		this.id_node = new HashMap<String, TextNode>();
	}
	
	/**
	 * Add a node to the text-graph
	 * The id is acutally a string occurred in the text
	 * @param id
	 */
	public void addNode(String id){
		if (id_node.get(id)==null)
			//if the id does not occur in the graph
			id_node.put(id, new TextNode(id));
		//else if the id already in the graph, simply do nothing
	}
	
	/**
	 * Add edge in the graph
	 * @param id1
	 * @param id2
	 */
	public void addEdge(String id1, String id2){
		if (id1.equals(id2)) return;//self-loop is not allowed.
		TextNode node1 = id_node.get(id1);
		TextNode node2 = id_node.get(id2);
		if (node1==null||node2==null){
			System.out.println("Error occur in adding edges!!!");
			System.exit(-1);
		}else{
			node1.addNeighbour(id2, 1);
			node2.addNeighbour(id1, 1);
			id_node.put(id1,node1);
			id_node.put(id2, node2);
		}
	}
	
	public XmlGraph convert2XmlGraph(){
		XmlGraph graph = new XmlGraph();
		HashSet<String> hs = new HashSet<String>();
		for (String id1:this.id_node.keySet()){
			graph.nodes.add(id1);
			TextNode node = this.id_node.get(id1);
			HashSet<String> neighbours = node.neighbours;
			HashMap<String, Double> weights = node.weights;
			for (String id2:neighbours){
				double weight = weights.get(id2);
				Edge edge = new Edge(id1,id2,weight);							
				if (hs.contains(id1+id2)){					
				}else{
					hs.add(id1+id2);
					hs.add(id2+id1);
					graph.edges.add(edge);
				}
			}
		}
		return graph;		
	}
}
