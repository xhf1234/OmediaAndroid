package toolbox.text.textrank;

/**
 * All the implementation of node should inherit INode
 */
public class INode {
	
	//each node should have a unique id in a graph
	String id;
	
	//initialization for a certain node
	public INode(String label){
		this.id = label;
	}
	
}
