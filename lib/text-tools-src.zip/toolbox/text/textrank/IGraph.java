package toolbox.text.textrank;

public interface IGraph {
		
}
