package toolbox.text.textrank;

public class Edge {
	
	public String nodeName1;
	public String nodeName2;
	public double weight;
	public Edge(String nam1, String nam2, double weight){
		this.nodeName1 = nam1;
		this.nodeName2 = nam2;
		this.weight = weight;
	}
}	
