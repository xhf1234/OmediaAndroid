package toolbox.text.textrank;

import java.util.ArrayList;
import java.util.List;

public class XmlGraph {
	public List<String> nodes;
	public List<Integer> ranks;
	public List<Edge>  edges;
	public XmlGraph(){
		this.nodes = new ArrayList<String>();
		this.edges = new ArrayList<Edge>();
		this.ranks = new ArrayList<Integer>();
	}
}
