package toolbox.text.util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Set;

import toolbox.text.patternsearch.StringLengthComparator;

/**
 * comile a set of suffix, and check whether a string ends with one of the
 * suffix the isSuffixInSet function is thread safe the compile function should
 * call at the begining
 * 
 * 
 * @author Mingjiang Ye (yemingjiang@rd.netease.com).
 * 
 * Copyright (c) 2006, Outfox Team
 */

public class SuffixSearcher {

	protected static final int DEFAULT_HASHMAP_CAPACITY = 16;

	protected static final float DEFAULT_HASHMAP_LOAD_FACTOR = 0.5f;

	protected HashMap<String, ArrayList<String>> suffixMap = new HashMap<String, ArrayList<String>>(
			DEFAULT_HASHMAP_CAPACITY, DEFAULT_HASHMAP_LOAD_FACTOR);

	protected int minLen = 0;

	/**
	 * pre-process the pattern set
	 * 
	 * @param suffixSet
	 *            The Prefix String set to be match.
	 * 
	 * @return true of false
	 */
	public boolean compile(Set<String> suffixSet) {
		if (suffixSet.size() <= 0)
			return false;

		minLen = Integer.MAX_VALUE;
		for (String suffix : suffixSet) {
			if (minLen > suffix.length())
				minLen = suffix.length();
		}
		if (minLen < 2)
			return false;
		// 0 1 (2, 3 ,4) (3,5
		for (String suffix : suffixSet) {
			String key = suffix.substring(suffix.length() - minLen, suffix
					.length());
			ArrayList<String> suffixLst = suffixMap.get(key);
			if (suffixLst == null) {
				suffixLst = new ArrayList<String>();
				suffixMap.put(key, suffixLst);
			}
			suffixLst.add(suffix);
		}
		
		// we have to sort the prefixLst to make sure the longest prefix will match first
		StringLengthComparator comp = new StringLengthComparator();
		for (ArrayList<String> lst : suffixMap.values()) {
			Collections.sort(lst, comp);
		}
		return true;
	}

	/**
	 * get the matched suffix, return null if not hit
	 * 
	 * @param text
	 *            The text to be searched.
	 */
	public String getHitSuffix(String text) {
		if (text.length() < minLen)
			return null;
		int startPos = text.length() - minLen;
		ArrayList<String> suffixLst = suffixMap.get(text.substring(startPos,
				text.length()));
		if (suffixLst == null)
			return null;

		// scan the prefix has the same substring key
		for (String suffix : suffixLst) {
			int suffixLen = suffix.length();
			// if the text longer than prefix length
			if (suffixLen <= text.length()) {
				boolean match = true;
				int offset = text.length() - suffixLen;
				int left = suffixLen - minLen;
				// compare from end to start
				for (int i = 0; i < left; i++) {
					if (text.charAt(i + offset) != suffix.charAt(i)) {
						match = false;
						break;
					}
				}

				if (match)
					return suffix;
			}
		}
		return null;
	}

	/**
	 * search the text for the suffix.
	 * 
	 * @param text
	 *            The text to be searched.
	 */
	public boolean isSuffixInSet(String text) {
		if ( getHitSuffix(text) == null)
			return false;
		return true;
	}
}
