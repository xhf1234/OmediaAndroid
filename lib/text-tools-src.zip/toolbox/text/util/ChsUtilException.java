/**
 * @(#)ChsUtilException.java, 2007-5-23. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.text.util;

/**
 *
 * @author mounttai
 *
 */
public class ChsUtilException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -626293543922001373L;

	public ChsUtilException() {
		super();
	}
	
	public ChsUtilException(String message) {
		super(message);
	}

}
