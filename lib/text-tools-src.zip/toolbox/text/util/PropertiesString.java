package toolbox.text.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Properties;

/**
 * Use one string to store properties.
 * We use "&" as splitter of lines.
 * @author river
 *
 */
public class PropertiesString {
	private static byte SPLITTER = (byte)'&';

	private static byte [] filterIn(byte [] buf) {
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		int len = buf.length;

		for (int i=0; i<len; i++) {
			byte b = buf[i];
			if (b == SPLITTER) {
				if (i < len -1) {
					if (buf[i+1] == SPLITTER) {
						i++;
						bos.write(SPLITTER);
					} else {
						bos.write('\n');
					}
				}
			} else {
				bos.write(b);
			}
		}

		return bos.toByteArray();
	}

	private static byte [] filterOut(byte [] buf) {
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		int len = buf.length;

		for (int i=0; i<len; i++) {
			byte b = buf[i];
			if (b == SPLITTER) {
				bos.write(SPLITTER);
				bos.write(SPLITTER);
			} else if (b == '\r') {

			} else if (b == '\n') {
				bos.write(SPLITTER);
			} else {
				bos.write(b);
			}
		}

		return bos.toByteArray();
	}

	/**
	 * Decode properties from string.
	 * @param s
	 * @return the decoded properties from the String
	 */
	public static Properties decode(String s) {
		byte [] bytes = s.getBytes();
		ByteArrayInputStream bis = new ByteArrayInputStream(filterIn(bytes));
		Properties result = new Properties();
		try {
			result.load(bis);
		} catch(IOException e) {
		}
		return result;
	}

	/**
	 * Encode properties into string.
	 * @param properties
	 * @return the encoded String from properties
	 */
	public static String encode(Properties properties) {
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		try {
			properties.store(bos, null);
		} catch(IOException e) {

		}
		byte [] bytes = filterOut(bos.toByteArray());
		return new String(bytes);
	}

}
