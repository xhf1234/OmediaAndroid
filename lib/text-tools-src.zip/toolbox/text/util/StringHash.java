package toolbox.text.util;

/**
 * string hash utility
 * 
 * Copyright (c) 2006, Outfox Team
 */
public class StringHash {

	/**
	 * Get the case insensitive hashCode.
	 * @param s  The string
	 * @return  Hashcode (case insensitive)
	 */
	public static int hashIgnoreCase(String s) {
		return hashIgnoreCase(s, 0, s.length());
	}

	/**
	 * Return hashCode of string s. Unlike {@link String#hashCode()}, this 
	 * hashCode won't change when the case of some characters changed in the 
	 * string. The hashCode without case information can be used at some case 
	 * insensitive environment.
	 *
	 * @param s  The string
	 * @param offset  Offset in the string
	 * @param length  Length from the offset
	 * @return  Hashcode (case insensitive)
	 */
	public static int hashIgnoreCase(String s, int offset, int length) {
		int hashCode = 0;
		int end = length + offset;
		for (int i = offset; i < end; i++) {
			hashCode = hashCode * 31 + (((int) s.charAt(i)) | (0x01 << 5));
		}
		return hashCode;
	}

	/**
	 * Get the case insensitive hashCode with spacing removed from the string.
	 * @param s  The string
	 * @return  Hashcode (case insensitive)
	 */
	public static int hashIgnoreCaseIgnoreSpace(String s) {
		return hashIgnoreCaseIgnoreSpace(s, 0, s.length());
	}

	/**
	 * Get the case insensitive hashCode with spacing removed from the string.
	 * @param s  The string
	 * @param offset  Offset in the string
	 * @param count  Length from the offset
	 * @return  Hashcode (case insensitive)
	 */
	public static int hashIgnoreCaseIgnoreSpace(String s, int offset, int count) {
		int hashCode = 0;
		int end = count + offset;
		for (int i = offset; i < end; i++) {
			char c = s.charAt(i);
			if (!Character.isWhitespace(c)) {
				hashCode = hashCode * 31 + (((int) c) | (0x01 << 5));
			}
		}
		return hashCode;
	}

	/**
	 * Get the case sensitive hashCode with spacing removed from the string.
	 * @param s  The string
	 * @return  Hashcode (case insensitive)
	 */
	public static int hashIgnoreSpace(String s) {
		return hashIgnoreSpace(s, 0, s.length());
	}

	/**
	 * Get the case sensitive hashCode with spacing removed from the string.
	 * @param s  The string
	 * @param offset  Offset in the string
	 * @param count  Length from the offset
	 * @return  Hashcode (case insensitive)
	 */
	public static int hashIgnoreSpace(String s, int offset, int count) {
		int hashCode = 0;
		int end = count + offset;
		for (int i = offset; i < end; i++) {
			char c = s.charAt(i);
			if (!Character.isWhitespace(c)) {
				hashCode = hashCode * 31 + ((int) c);
			}
		}
		return hashCode;
	}
}
