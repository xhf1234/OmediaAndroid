package toolbox.text.util;


/**
 * String comparison utilities
 * 
 * Copyright (c) 2006, Outfox Team
 */
public class StringComparison {

    /**
     * Compares two strings, all the white spaces are ignored. 
     * For example, returns true when s1 is "a b" and s2 is "ab".
     * 
     * @param s1  the first string
     * @param s2  the second string
     * @return whether these two string equals ignoring spaces
     */
    public static boolean equalsIgnoreSpace(String s1, String s2) {
        int i = 0, j = 0;
        int len1 = s1.length();
        int len2 = s2.length();
        char[] array1 = s1.toCharArray();
        char[] array2 = s2.toCharArray();
        while (i < len1 && j < len2) {
            char ch1 = array1[i++];
            while (i < len1 && Character.isWhitespace(ch1)) {
                ch1 = array1[i++];
            }

            char ch2 = array2[j++];
            while (j < len2 && Character.isWhitespace(ch2)) {
                ch2 = array2[j++];
            }

            if (i == len1 && j == len2)
                return true;

            if (ch1 != ch2)
                return false;
        }
        if (i < len1) {
            for (; i < len1 && Character.isWhitespace(array1[i]); i++);
        }
        if (j < len2) {
            for (; j < len2 && Character.isWhitespace(array2[j]); j++);
        }
        if (i < len1 || j < len2) {
            return false;
        }
        return true;
    }

    /**
     * Calculates the edit distance between two strings
     * 
     * @param s1 the first string
     * @param s2 the second string
     * @return the edit distance
     */
    public static int editDistance(String s1, String s2) {
        int[] last = new int[s2.length() + 1];
        int[] now = new int[s2.length() + 1];
        for (int j = 0; j <= s2.length(); j++)
            last[j] = j;

        for (int i = 1; i <= s1.length(); i++) {
            now[0] = i;
            for (int j = 1; j <= s2.length(); j++) {
                if (s2.charAt(j - 1) == s1.charAt(i - 1)) {
                    now[j] = last[j - 1];
                } else {
                    // three operations: add, del, replace
                    now[j] = Math.min(now[j - 1], 
                            Math.min(last[j], last[j - 1])) + 1;
                } // else
            } // for j
            int[] tmp = now;  now = last;  last = tmp;
        } // for i

        return last[s2.length()];
    }
}
