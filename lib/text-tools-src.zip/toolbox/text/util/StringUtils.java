package toolbox.text.util;

import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.Random;

/**
 * Some miscellaneous string utilities.
 * 
 * Copyright (c) 2006, Outfox Team
 * 
 * @author XXX, David
 */

public class StringUtils {
    /**
     * Return an abbreviated English-language desc of the byte length. The
     * float part is formated as a "%.3f" format with.
     * 
     * @param bytes  the bytes to be shown
     * @return  the translated string
     */
    public static String bytesAbbr(long bytes) {
        double val = 0.0;
        String ending = "";
        if (bytes < 1024) {
            return "" + bytes;
        } else if (bytes < 1024 * 1024) {
            val = (1.0 * bytes) / 1024;
            ending = "K";
        } else if (bytes < 1024 * 1024 * 1024) {
            val = (1.0 * bytes) / (1024 * 1024);
            ending = "M";
        } else if (bytes < 1024L * 1024 * 1024 * 1024) {
            val = (1.0 * bytes) / (1024 * 1024 * 1024);
            ending = "G";
        } else if (bytes < 1024L * 1024L * 1024L * 1024L * 1024L) {
            val = (1.0 * bytes) / (1024L * 1024L * 1024L * 1024L);
            ending = "T";
        } else {
            val = (1.0 * bytes) / (1024L * 1024L * 1024L * 1024L * 1024L);
            ending = "P";
        } // else
        return String.format("%.3f", val) + ending;
    }

    /**
     * Convert an interval in milli-seconds into a human readable text.
     * 
     * @param interval  the interval to be converted
     * @return  the converted text
     */
    public static String intervalToString(long interval) {
        double val = 0.0;
        String ending = "";
        if (interval < 1000)
            return "" + interval + "msec";
        else if (interval < 60 * 1000) {
            val = (double) interval / 1000.;
            ending = "sec";
        } else if (interval < 60L * 60L * 1000L ) {
            val = (double) interval / 60. / 1000.;
            ending = "min";
        } else if (interval < 24L * 60L * 60L * 1000L ) {
            val = (double) interval / 60. / 60. / 1000.;
            ending = "h";
        } else {
            val = (double) interval / 24. / 60. / 60. / 1000.;
            ending = "day";
        } // else
        return String.format("%.2f", val) + ending;
    }

    /**
     * Insert separator-char into an count long.
     * e.g. countSep(12345, ",", 3) returns "12,345".
     * 
     * @param count  the count to be shown
     * @param sep  the separator-char
     * @param skip  the number of digits between two separator.
     * @return
     */
    public static String countSep(long count, String sep, int skip) {
        StringBuilder str = new StringBuilder("" + count);
        int idx = str.length() % skip;
        if (idx == 0)
            idx = 4;
        int cnt = (str.length() - 1) / skip;
        for (int i = 0; i < cnt; i ++) {
            str.insert(idx, sep);
            idx += skip + sep.length();
        } // for i
        return str.toString();
    }
    
    /**
     * The interface for integer filtering. This is designed for 
     * selecting segments. You need to set the lastInteger which
     * corresponds to ":" in parsing numbers.
     * 
     * @author David
     *
     */
    public static interface IntegerFilter {
        /**
         * Set the maximum number in the integer set.
         * 
         * @param max  the maximum number
         */
        void setLastInteger(int max);
        /**
         * Check if the set contains this number or this number needs be
         * filtered out.
         * 
         * @param num  the number to be checked.
         * @return  true if num is in the set, false otherwise.
         */
        boolean contains(int num);
    }
    /**
     * Parse the number-set string and returns an IntegerFilter as the result.
     * The following format is supported:
     *   1)  <num>, e.g. 1
     *   2) <min>-<max>, e.g. 2-5 mean 2,3,4,5
     *   3) <num>+, e.g. 10+ means all integers greater than or equal to 10
     *   4) <num>-, e.g. 10- means all integers less than or equal to 10
     *   5) <range>,<rang>, e.g. 1-2,5-6,8 means the union of all the sets.
     *   6) a, means all integers
     *   7) :, means the LastInteger
     * 
     * @param str  the number-set string
     * @return  the generated IntegerFilter. After setting the LastInteger, you can
     *          use this filter to check if an integer is in the set represented by
     *          str.
     */
    public static IntegerFilter parseNumbers(String str) {
        class FlexibleFilter implements IntegerFilter {
            private int max = -1;
            boolean all = false;
            boolean last = false;
            HashSet<Integer> nums = new HashSet<Integer>();
            ArrayList<Integer> leq = new ArrayList<Integer>();
            ArrayList<Integer> geq = new ArrayList<Integer>();
            public boolean contains(int num) {
                if (all)
                    return true;
                if (last && num == max)
                    return true;
                if (nums.contains(num))
                    return true;
                for (Integer i: leq)
                    if (num <= i)
                        return true;
                for (Integer i: geq)
                    if (num >= i)
                        return true;
                return false;
            }

            public void setLastInteger(int max) {
                this.max = max;
            }
        };
        
        FlexibleFilter res = new FlexibleFilter();
        
        if (str.equals("a")) {
            res.all = true;
        } else {
            for (String segm: str.split("[,;]")) {
                if (segm.equals(":")) {
                    res.last = true;
                } else if (segm.matches("[0-9]+\\+")) {
                    res.geq.add(Integer.parseInt(segm.substring(0, segm.length() - 1)));
                } else if (segm.matches("[0-9]+-")) {
                    res.leq.add(Integer.parseInt(segm.substring(0, segm.length() - 1)));
                } else if (segm.matches("[0-9]+-[0-9]+")) {
                    String[] ranges = segm.split("-");
                    if (ranges.length != 2) {
                        new RuntimeException("Range should be formatted as xxx-xxx.");
                    } // if
                    int min = Integer.parseInt(ranges[0]);
                    int max = Integer.parseInt(ranges[1]);
                    for (int i = min; i <= max; i ++)
                        res.nums.add(i);
                } else {
                    res.nums.add(Integer.parseInt(segm));
                } // else
            } // for segm
        } // else
        
        return res;
    }
    /**
     * The comment string for using of parseNumber
     */
    public static String PARSE_NUMBERS_COMMENT =
        "Parse the number-set string and returns an IntegerFilter as the result.\n" +
        "The following format is supported:\n" +
        "  1)  <num>, e.g. 1\n" +
        "  2) <min>-<max>, e.g. 2-5 means 2,3,4,5\n" +
        "  3) <num>+, e.g. 10+ means all integers greater than or equal to 10\n" +
        "  4) <num>-, e.g. 10- means all integers less than or equal to 10\n" +
        "  5) <range>,<rang>, e.g. 1-2,5-6,8 means the union of all the sets.\n" +
        "  6) a, means all integers\n" +
        "  7) :, means the LastInteger\n";
    
    /**
     * Returns a copy of <code>s</code> padded with trailing spaces so that
     * it's length is <code>length</code>. Strings already
     * <code>length</code> characters long or longer are not altered.
     */
    public static String rightPad(String s, int length) {
        StringBuilder sb = new StringBuilder(s);
        for (int i = length - s.length(); i > 0; i--)
            sb.append(" ");
        return sb.toString();
    }

    /**
     * Returns a copy of <code>s</code> padded with leading spaces so that
     * it's length is <code>length</code>. Strings already
     * <code>length</code> characters long or longer are not altered.
     * 
     * @param s
     *            The string for padding.
     * @param length
     *            Expected length after padding
     * @return The string after padding.
     */
    public static String leftPad(String s, int length) {
        return leftPad(s, length, ' ');
    }

    /**
     * Returns a copy of <code>s</code> padded with leading <code>c</code>
     * so that it's length is <code>length</code>. Strings already
     * <code>length</code> characters long or longer are not altered.
     * 
     * @param s
     *            The string for padding.
     * @param length
     *            Expected length after padding
     * @param c
     *            The char for padding.
     * @return The string after padding.
     */
    public static String leftPad(String s, int length, char c) {
        StringBuilder sb = new StringBuilder();
        for (int i = length - s.length(); i > 0; i--)
            sb.append(c);
        sb.append(s);
        return sb.toString();
    }

    public static String capitalString(String str) {
        if (str == null || str.length() < 1) {
            return str;
        }
        return str.substring(0, 1).toUpperCase() + str.substring(1);
    }

    public static String indentString(String str, String indentation) {
        String[] list = str.split("\n");
        StringBuilder sb = new StringBuilder();
        for (String s : list) {
            sb.append(indentation).append(s).append("\n");
        }
        return sb.toString();
    }

    public static String concatStrings(String[] ss, String delim) {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < ss.length; i++) {
            if (i != 0)
                sb.append(delim);
            sb.append(ss[i]);
        }
        return sb.toString();
    }

    public static String dateToString(long d) {
        return dateToString(d, "yyyy-MM-dd HH:mm:ss");
    }

    /**
     * Letter Date Component Presentation Examples G Era designator Text AD y
     * Year Year 1996; 96 M Month in year Month July; Jul; 07 w Week in year
     * Number 27 W Week in month Number 2 D Day in year Number 189 d Day in
     * month Number 10 F Day of week in month Number 2 E Day in week Text
     * Tuesday; Tue a Am/pm marker Text PM H Hour in day (0-23) Number 0 k Hour
     * in day (1-24) Number 24 K Hour in am/pm (0-11) Number 0 h Hour in am/pm
     * (1-12) Number 12 m Minute in hour Number 30 s Second in minute Number 55
     * S Millisecond Number 978 z Time zone General time zone Pacific Standard
     * Time; PST; GMT-08:00 Z Time zone RFC 822 time zone -0800 For example:
     * Date and Time Pattern Result "yyyy.MM.dd G 'at' HH:mm:ss z" 2001.07.04 AD
     * at 12:08:56 PDT "EEE, MMM d, ''yy" Wed, Jul 4, '01 "h:mm a" 12:08 PM "hh
     * 'o''clock' a, zzzz" 12 o'clock PM, Pacific Daylight Time "K:mm a, z" 0:08
     * PM, PDT "yyyyy.MMMMM.dd GGG hh:mm aaa" 02001.July.04 AD 12:08 PM "EEE, d
     * MMM yyyy HH:mm:ss Z" Wed, 4 Jul 2001 12:08:56 -0700 "yyMMddHHmmssZ"
     * 010704120856-0700 "yyyy-MM-dd'T'HH:mm:ss.SSSZ"
     * 2001-07-04T12:08:56.235-0700
     * 
     * @param d
     * @param format
     * @return the foramtted string
     */
    public static String dateToString(long d, String format) {
        SimpleDateFormat formatter = new SimpleDateFormat(format);
        return formatter.format(new Date(d));
    }

    private static Random RANDOM = new Random();

    /**
     * Generate a random string of assigned length
     * 
     * @param len
     *            The length of string
     * @return The random string generated
     */
    public static String randomString(int len) {
        StringBuilder sb = new StringBuilder("random");
        for (int i = 0; i < len; i++) {
            sb.append(Integer.toHexString(RANDOM.nextInt(16)));
        }
        return sb.toString();
    }

    /**
     * Layout a string given the size on each line and wrap methods
     * 
     * @param text  the string to layout
     * @param size  the wrap size of each line
     * @param wrap  one of "left", "right", or "ends"
     * @return  a list of string in each line
     */
    public static ArrayList<String> layout(String text, int size, String wrap) {
        ArrayList<String> res = new ArrayList<String>();
        if (text == null)
            text = "";
        String[] lines = text.split("\n");
        for (String srcLine : lines) {
            String[] words = srcLine.split(" +");
            int idx = 0;
            while (idx < words.length) {
                int len = words[idx].length();
                int idx_1 = idx + 1;
                while (idx_1 < words.length
                        && len + words[idx_1].length() + 1 <= size) {
                    len += words[idx_1].length() + 1;
                    idx_1++;
                } // while

                int len_rem = size - len;
                if (len_rem < 0)
                    len_rem = 0;
                String line;
                if ("right".equals(wrap)) {
                    line = words[idx];
                    for (int i = idx + 1; i < idx_1; i++)
                        line += " " + words[i];
                    if (len_rem > 0)
                        line = String.format("%" + len_rem + "s", "") + line;
                } else if ("ends".equals(wrap) && idx_1 < words.length) {
                    line = words[idx];
                    int num_words = idx_1 - idx;
                    for (int i = idx + 1; i < idx_1; i++) {
                        line += String
                                .format(
                                        "%"
                                                + (1 + len_rem
                                                        / (num_words - 1) + ((i
                                                        - idx - 1) < (len_rem % (num_words - 1)) ? 1
                                                        : 0)) + "s", "")
                                + words[i];
                    } // for i
                } else {
                    // default is left
                    line = words[idx];
                    for (int i = idx + 1; i < idx_1; i++)
                        line += " " + words[i];
                    if (len_rem > 0)
                        line += String.format("%" + len_rem + "s", "");
                } // else
                res.add(line);

                idx = idx_1;
            } // while
        } // for srcLine
        return res;
    }

    /**
     * Return if the string is null or zero-length.
     * 
     * @return
     */
    public static final boolean isEmptyString(String s) {
        return (s == null || s.length() == 0);
    }

    static final char[] HEX_DIGITS = new char[] { '0', '1', '2', '3', '4', '5',
            '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };

    /**
     * Convert byte array to hex string.
     * @param buf
     * @param off
     * @param len
     * @return
     * @deprecated Use HexString.bytesToHex 7/26/2007
     */
    @Deprecated
    public static String bytesToHex(byte[] buf, int off, int len) {
        StringBuilder builder = new StringBuilder(len * 2);
        for (int i = 0; i < len; i++) {
            byte b = buf[off + i];
            builder.append(HEX_DIGITS[(b >> 4) & 0x0f]);
            builder.append(HEX_DIGITS[b & 0x0f]);
            builder.append(' ');
        }
        if (builder.length() > 0)
            builder.setLength(builder.length() - 1);
        return builder.toString();
    }

    /**
     * Convert hex string to by array.
     * @param s
     * @return
     * @throws ParseException
     * @deprecated Use HexString.hexToBytes 7/26/2007
     */
    @Deprecated
    public static byte[] hexToBytes(String s) throws ParseException {
        byte[] bytes = new byte[s.length() / 2];
        int len = 0;

        int i = 0;
        while (i < s.length()) {
            char c = s.charAt(i);
            if (c == ' ' || c == '\r' || c == '\n' || c == '\t') {
                i++;
                continue;
            }
            int b = 0;

            int j = 0;
            do {
                if (c >= 'a' && c <= 'f') {
                    b = b << 4 | (c - 'a' + 10);
                } else if (c >= 'A' && c <= 'F') {
                    b = b << 4 | (c - 'A' + 10);
                } else if (c >= '0' && c <= '9') {
                    b = b << 4 | (c - '0');
                } else {
                    throw new ParseException(s, i);
                }
                i++;
                j++;
                if (j == 2) {
                    break;
                } else {
                    if (i >= s.length()) {
                        throw new ParseException(s, i);
                    }
                    c = s.charAt(i);
                }
            } while (true);
            bytes[len++] = (byte) b;
        }

        if (len == bytes.length) {
            return bytes;
        } else {
            byte[] result = new byte[len];
            System.arraycopy(bytes, 0, result, 0, len);
            return result;
        }
    }

    /**
     * Convert an int to unsigned, 0-padded, 8-digit hex.
     * @deprecated Use HexString.intToPaddedHex 7/26/2007
     */
    @Deprecated
    public static String intToPaddedHex(int x) {
        char[] buf = new char[8];
        for (int i = 0; i < 4; i++) {
            int shift = ((3 - i) << 3);
            buf[(i << 1)] = HEX_DIGITS[(x >> (shift + 4)) & 0xf];
            buf[(i << 1) + 1] = HEX_DIGITS[(x >> shift) & 0xf];
        }
        return new String(buf);
    }

    /**
     * @deprecated Use HexString.longToPaddedHex 7/26/2007
     */
    @Deprecated
    public static String longToPaddedHex(long x) {
        char[] buf = new char[16];
        for (int i = 0; i < 8; i++) {
            int shift = ((7 - i) << 3);
            buf[(i << 1)] = HEX_DIGITS[(int) ((x >> (shift + 4)) & 0xf)];
            buf[(i << 1) + 1] = HEX_DIGITS[(int) ((x >> shift) & 0xf)];
        }
        return new String(buf);
    }

    public static String numTo4Chars(double num) {
        if (num < 10.)
            return String.format("%4.2f", num);
        if (num < 100.)
            return String.format("%4.1f", num);
        return String.format("%4.0f", num);
    }

    /**
     * Return an abbreviated English-language desc of the byte length
     */
    public static String byteDesc(long len) {
        double val = 0.0;
        String ending = "";
        if (len < 1024)
            return String.format("%4s", len) + " ";
        else if (len < 1024 * 1024) {
            val = (1.0 * len) / 1024;
            ending = "K";
        } else if (len < 1024 * 1024 * 1024) {
            val = (1.0 * len) / (1024 * 1024);
            ending = "M";
        } else if (len < 1024L * 1024 * 1024 * 1024) {
            val = (1.0 * len) / (1024 * 1024 * 1024);
            ending = "G";
        } else if (len < 1024L * 1024L * 1024L * 1024L * 1024L) {
            val = (1.0 * len) / (1024L * 1024L * 1024L * 1024L);
            ending = "T";
        } else {
            val = (1.0 * len) / (1024L * 1024L * 1024L * 1024L * 1024L);
            ending = "P";
        } // else
        return numTo4Chars(val) + ending;
    }

    /**
     * Return String with limited demical count, for example, "2.45" for limitDecimal(2.456,2).
     * @param d
     * @param placesAfterDecimal
     * @return
     */
    public static String limitDecimal(double d, int placesAfterDecimal) {
        String strVal = Double.toString(d);
        int decpt = strVal.indexOf(".");
        if (decpt >= 0) {
            strVal = strVal.substring(0, Math.min(strVal.length(), decpt + 1
                    + placesAfterDecimal));
        }
        return strVal;
    }

    /**
     * Print option info of an application. The options are be left aligned, and the comments
     * are aligned by ends. 
     * 
     * @param out  the PrintWriter for printing
     * @param indent  the indent for all lines
     * @param maxOptLen  the maximum length of the option column
     * @param maxWidth  the maximum width of the columns including the length of indent
     * @param options  the option pairs, i.e. <option>, <comment>, <option>, <comment>
     */
    public static void printOptionsInfo(PrintWriter out, String indent, int maxOptLen, int maxWidth, String... options) {
        int cnt = options.length / 2;
        String[] opts = new String[cnt];
        String[] infos = new String[cnt];

        /*
         * Separate option and comments, and compute optLen.
         */
        int optLen = 0;
        for (int i = 0; i < cnt; i ++) {
            opts[i] = options[i * 2];
            infos[i] = options[i*2 + 1];

            if (opts[i].length() > optLen)
                optLen = opts[i].length();
        } // for i

        if (optLen > maxOptLen)
            optLen = maxOptLen;
        /*
         * Print lines. 
         */
        for (int i = 0; i < cnt; i ++) {
            ArrayList<String> lines = layout(infos[i], maxWidth - indent.length() - optLen - 2, "ends");
            for (int j = 0; j < lines.size(); j ++) {
                out.print(indent);
                if (j == 0) {
                    if (opts[i].length() <= optLen) {
                        out.format("%-" + optLen + "s", opts[i]);
                    } else {
                        out.println(opts[i]);
                        out.format("%s%" + optLen + "s", indent, "");
                    } // else
                } else {
                    out.format("%" + optLen + "s", "");
                } // else
                out.print("  ");
                out.println(lines.get(j));
            } // for j
        } // for i
    }

    /**
     * Cat all the elements in array together with given delimeter <code>"delim"</code>.
     * The returned value for call 
     * <code>
     *    arrayToString(new String[]{"a", "b"}, ",")
     * </code>
     * should be "a,b".
     * 
     * @param arr
     * @param delim
     * @return
     */
    public static String arrayToString(Object [] arr, String delim) {
        if (arr == null) return "null";
        if (arr.length == 0) return "";
        
        StringBuilder buf = new StringBuilder();
        buf.append(arr[0]);
        for (int i=1; i<arr.length; i++) {
            buf.append(delim).append(arr[i]);
        }
        return buf.toString();
    }
    
}
