/**
 * @(#)QueryEncodingDetector.java, Dec 7, 2010. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.lang;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.HashSet;
import java.util.Set;

/**
 * 检测查询的编码
 * 对中文查询使用 probablyUtf8ForChn, 对有小语种的情况使用 probablyUTF8
 * 
 * 相关实验wiki: 
 *   https://dev.corp.youdao.com/outfoxwiki/WebSearch/QueryEncodingDetector
 *
 * @author zhanglh
 *
 */
public class QueryEncodingDetector {
    
    /**
     * 判断中文查询是utf8编码还是gbk编码
     * 如果可以解码成中文的utf8串，或者不能用gbk解码，就判断是utf8编码。否则是gbk编码
     * 
     * 对中文查询的判断准确度很高，但对小语种有一定的误判，会把一些utf8的小语种查询识别成gbk
     * 
     * @param data
     * @return
     */
    public static boolean probablyUtf8ForChn(byte []data) {
        boolean probablyChineseUtf8 = probablyChineseUtf8(data);
        if (probablyChineseUtf8)
            return true;
        boolean probablyGbk = probablyGbk(data);
        return probablyGbk ? false : true;
    }
    
    /**
     * copy from toolbox.web.ViewUtils.probablyUTF8
     * 判断查询是否是utf8编码的，只检查了是utf8编码的准确度
     * 
     * 对中文识别准确度比 probablyUtf8ForChn 低，但对小语种识别的准确度要高
     * 
     * @param rawtext
     * @return
     */
    public static boolean probablyUTF8(byte[] rawtext) {
        int score = 0;
        int i, rawtextlen = 0;
        int goodbytes = 0, asciibytes = 0;

        // Maybe also use UTF8 Byte Order Mark: EF BB BF

        // Check to see if characters fit into acceptable ranges
        rawtextlen = rawtext.length;
        for (i = 0; i < rawtextlen; i++) {
            if ((rawtext[i] & (byte) 0x7F) == rawtext[i]) { // One byte
                asciibytes++;
                // Ignore ASCII, can throw off count
            } else if (-64 <= rawtext[i] && rawtext[i] <= -33
                    && // Two bytes
                    i + 1 < rawtextlen && -128 <= rawtext[i + 1]
                    && rawtext[i + 1] <= -65) {
                goodbytes += 2;
                i++;
            } else if (-32 <= rawtext[i]
                    && rawtext[i] <= -17
                    && // Three bytes
                    i + 2 < rawtextlen && -128 <= rawtext[i + 1]
                    && rawtext[i + 1] <= -65 && -128 <= rawtext[i + 2]
                    && rawtext[i + 2] <= -65) {
                goodbytes += 3;
                i += 2;
            }
        }

        if (asciibytes == rawtextlen) {
            return false;
        }

        score = (int) (100 * ((float) goodbytes / 
                    (float) (rawtextlen - asciibytes)));
        // If not above 98, reduce to zero to prevent coincidental matches
        // Allows for some (few) bad formed sequences
        if (score > 98) {
            return true;
        } else if (score > 95 && goodbytes > 30) {
            return true;
        } else {
            return false;
        }
    }
    
    private static boolean isStrangeChar(char c) {
        if (ChnConstant.isAsciiChar(c) || ChnConstant.isChineseChar(c) 
                || ChnConstant.isDelimiter(c)
             // || ChnConstant.isJapaneseChar(c) || ChnConstant.isKoreanChar(c)
             // || ChnConstant.isOtherAlphabet(c)
                || PUNCT_SET.contains(c))
            return false;
        return true;
    }
    
    private static final String PUNCT_DEFAULT = 
        // english punctuations
        "!\"#$%&\'()*+,-./:;<=>?@[\\]^_`{|}~" +
        // chinese punctuations
        "　 　 ．！“”＃＄％＆‘’（）＊＋，—－。／：；＜＝＞？＠［、］…＿｀｛｜｝～" +
        "『』「」╗╚┐└《》〈〉·•〔〕" +
        // special characters
        "±×÷∶￡￥‰‖〖〗【】√≈≤≥≦≧≌≒≠≮≯′″♂♀°℃§※π№☆★○●◇◆□■△▲▽▼⊙⊕◎Θ¤㊣◣◢◤◥▷▶◁◀" +
        "↔↕↑↓→←↘↙↖↗∵∴∷々∞Ψ∪∩∈∏∫∮∝∧∨∑∠⌒⊿⊥∟︵︶︷︸︹︺︻︼︽︾︿﹀﹁﹂﹃﹄" +
        "©®♥ⓒ»¥ⅠⅡ┆ﬁﬂ";
    private static final Set<Character> PUNCT_SET = new HashSet<Character>();
    static {
        for (int i = 0; i < PUNCT_DEFAULT.length(); i++) {
            PUNCT_SET.add(PUNCT_DEFAULT.charAt(i));
        }
    }   

    /**
     * 判断是否是中文的utf8字符串
     * 
     * @param rawtext
     * @return
     */
    private static boolean probablyChineseUtf8(byte []rawtext) {
        // 第一步，检测是否可以解码
        int end = rawtext.length;
        for (int i = 0; i < end; i++) {
            byte b = rawtext[i];
            if ((b & (byte) 0x7F) == b) { // One byte
                // Ignore ASCII, can throw off count
            } else if (-64 <= b && b <= -33 && // Two bytes
                    i + 1 < end && -128 <= rawtext[i + 1]
                    && rawtext[i + 1] <= -65) {
                i++;
            } else if (-32 <= b && b <= -17 && // Three bytes
                    i + 2 < end && -128 <= rawtext[i + 1]
                    && rawtext[i + 1] <= -65 && -128 <= rawtext[i + 2]
                    && rawtext[i + 2] <= -65) {
                i += 2;
            } else {
                return false;
            }
        }
        
        // 第二步检测解码后的字符集
        try {
            String str = new String(rawtext, "utf8");
            for (int i = 0; i < str.length(); i ++) {
                if (isStrangeChar(str.charAt(i)))
                    return false;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return true;
    }
    
    /**
     * 判断是否能用GBK解码
     * 
     * @param rawtext
     * @return
     */
    public static boolean probablyGbk(byte[] rawtext) {
        int i = 0;
        for (; i < rawtext.length - 1; i ++) {
            byte b = rawtext[i];
            if (b < 0) {
                byte next = rawtext[i + 1];
                if ((byte)0xA1 <= b && b <= (byte)0xF7 && (byte)0xA1 <= next
                        && next <= (byte)0xFE) {
                    // Origin GB range
                } else if ((byte)0x81 <= b && b <= (byte)0xFE &&
                        (((byte)0x80 <= next && next <= (byte)0xFE) || 
                                ((byte)0x40 <= next && next <= (byte)0x7E))) {
                    // Extended GB range
                } else {
                    return false;
                }
                i ++;
            }
        }
        
        if (i < rawtext.length && rawtext[i] < 0)
            return false;
        return true;
    }
    
    private static boolean isAsciiString(String str) {
        for (int i = 0; i < str.length(); i ++) {
            if (!ChnConstant.isAsciiChar(str.charAt(i)))
                return false;
        }
        return true;
    }
    
    /**
     * 通过读入query文件来检测编码识别的准确度
     * 评价的方法是把查询分别用utf8和gbk进行编码，看识别是否正确
     * 
     * @param args  filename
     * @throws Exception
     */
    public static void main(String []args) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(
                new FileInputStream(args[0]), "utf-8"));
        String line;
        int total = 0, totalUtf8Right = 0, totalGbk = 0, totalGbkRight = 0;
        while ((line = reader.readLine()) != null) {
            String query = line.trim();
            query = TraditionToSimple.convert(query);
            query = query.replace("?", ""); // 去掉原串中的 ?, 为之后判断编码是否成功
            if (query.length() == 0)
                continue;
            
            if (isAsciiString(query)) // ascii string 编码结果是一样的，比较没有意义
                continue;
            
            total ++;
            
            // 检测utf8编码
            byte []bytes = query.getBytes("utf8");
            int isUtf8Right = probablyUtf8ForChn(bytes) ? 1 : 0;
            totalUtf8Right += isUtf8Right;
            
            // 检测gbk编码
            bytes = query.getBytes("gbk"); // 可能gbk编码失败
            String gbkStr = new String(bytes, "gbk");

            if (gbkStr.indexOf('?') >= 0) {
                // gbk编码失败
                System.out.println(isUtf8Right + "\t" + "*" + "\t" + query);
                continue;
            }
            
            totalGbk ++;
            int isGbkRight = probablyUtf8ForChn(bytes) ? 0 : 1;
            totalGbkRight += isGbkRight; 
            System.out.println(isUtf8Right + "\t" + isGbkRight + "\t" + query);
        }
        
        System.out.println(total + "\t" + totalUtf8Right + 
                "\t" + totalGbk + "\t" + totalGbkRight);
    }
}
