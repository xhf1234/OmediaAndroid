package toolbox.lang.encdetect.specificencoding;

import toolbox.lang.encdetect.Encoding;

/**
 * Korean,EUC_KREncoding
 * @author xudq
 *
 */
public class EUC_KREncoding implements Encoding {

    public final String getName() {
        return "EUC-KR";
    }

    /*
     * Argument: pointer to byte array 
     * Returns : number from 0 to 100 representing probability 
     * text in array uses EUC-KR encoding
     */

    public final int probability(byte[] rawtext, int offset, int size,
            int checkLength) {
        int dbchars = 1, krchars = 1;
        long krfreq = 0, totalfreq = 1;
        float rangeval = 0, freqval = 0;
        int row, column;

        // Stage 1: Check to see if characters fit into acceptable ranges

        int end = offset + size;
        for (int i = offset; i < end - 1; i++) {
            // System.err.println(rawtext[i]);
            if (rawtext[i] >= 0) {
                // asciichars++;
            } else {
                dbchars++;
                if (dbchars >= checkLength) {
                    break;
                }
                if ((byte) 0xA1 <= rawtext[i] && rawtext[i] <= (byte) 0xFE
                        && (byte) 0xA1 <= rawtext[i + 1]
                        && rawtext[i + 1] <= (byte) 0xFE) {
                    krchars++;
                    totalfreq += 500;
                    row = rawtext[i] + 256 - 0xA1;
                    column = rawtext[i + 1] + 256 - 0xA1;
                    if (CP949Encoding.KRFreq[row][column] != 0) {
                        krfreq += CP949Encoding.KRFreq[row][column];
                    } else if (15 <= row && row < 55) {
                        krfreq += 0;
                    }

                }
                i++;
            }
        }
        rangeval = 50 * ((float) krchars / (float) dbchars);
        freqval = 50 * ((float) krfreq / (float) totalfreq);

        return (int) (rangeval + freqval + 0.5);
    }

}
