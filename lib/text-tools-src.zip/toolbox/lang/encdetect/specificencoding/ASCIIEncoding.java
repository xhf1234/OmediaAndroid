/*
 * Copyright (c) 2005,
 *  Yitao Duan, Jimmy Su, Feng Zhou and Li Zhuang
 *
 * Created on Aug 21, 2005
 */
package toolbox.lang.encdetect.specificencoding;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import toolbox.lang.encdetect.Encoding;

/**
 * English ASCIIEncoding
 *
 * @author ET,xudq
 */

public class ASCIIEncoding implements Encoding {
	
	public final String getName() {
		return "ISO-8859-1";
	}
	
     /*
     * Argument: byte array 
     * Returns : number from 0 to 100 representing probability
     * text in array uses all ASCII
     * Description: Sees if array has any characters not in ASCII range,
     * if so, score is reduced
     */
    public final int probability(byte[] rawtext, int offset, int size, int checkLength) {
        int score = 75;
        
        int end = offset + size;
        for (int i = offset; i < end; i++) {
            if (rawtext[i] < 0) {
                score = score - 5;
            } else if (rawtext[i] == (byte) 0x1B) { // ESC (used by ISO 2022)
                score = score - 5;
            }
            if (score <= 0) {
                return 0;
            }
        }

        return score;
    }

	public static void main(String[] args) throws IOException {
		if (args.length < 1) {
			System.out.println("Usage: ASCIIEncoding filename [numbytes]");
			System.exit(1);
		}

		File file = new File(args[0]);
		FileInputStream stream = new FileInputStream(file);

		int len = 100000;
		if (args.length > 1) {
			try {
				len = Integer.parseInt(args[1]);
			} catch (NumberFormatException e) {
			}
		}

		len = Math.min(len, (int) file.length());

		byte[] rawtext = new byte[len];
		stream.read(rawtext, 0, len);
		stream.close();
		ASCIIEncoding encoding = new ASCIIEncoding();
		System.out.println("File: " + file + ". Examined " + len + " bytes. "
				+ encoding.getName() + " probability: "
				+ encoding.probability(rawtext, 0, rawtext.length, len));
	}
}
