package toolbox.lang.encdetect.specificencoding;

import toolbox.lang.encdetect.Encoding;

/**
 * Traditional Chinese,EUC_TWEncoding
 * @author xudq
 *
 */
public class EUC_TWEncoding implements Encoding {
    static int[][] EUC_TWFreq = new int[94][94];
    static{
        initialize_frequencies();
    }
    public String getName() {
        return "EUC-TW";
    }

    /*
     * Argument: byte array 
     * Returns : number from 0 to 100 representing probability 
     * text in array uses EUC-TW (CNS 11643) encoding
     */

    public final int probability(byte[] rawtext, int offset, int size,
            int checkLength) {
        int dbchars = 1, cnschars = 1;
        long cnsfreq = 0, totalfreq = 1;
        float rangeval = 0, freqval = 0;
        int row, column;

        // Check to see if characters fit into acceptable ranges
        // and have expected frequency of use

        int end = offset + size;
        for (int i = offset; i < end - 1; i++) {
            if (rawtext[i] >= 0) { // in ASCII range
                // asciichars++;
            } else { // high bit set
                dbchars++;
                if(dbchars >= checkLength){
                    break;
                }
                if (i + 3 < end && (byte) 0x8E == rawtext[i]
                        && (byte) 0xA1 <= rawtext[i + 1]
                        && rawtext[i + 1] <= (byte) 0xB0
                        && (byte) 0xA1 <= rawtext[i + 2]
                        && rawtext[i + 2] <= (byte) 0xFE
                        && (byte) 0xA1 <= rawtext[i + 3]
                        && rawtext[i + 3] <= (byte) 0xFE) { // Planes 1 - 16

                    cnschars++;
                    // System.out.println("plane 2 or above CNS char");
                    // These are all less frequent chars so just ignore freq
                    i += 3;
                } else if ((byte) 0xA1 <= rawtext[i]
                        && rawtext[i] <= (byte) 0xFE
                        && // Plane 1
                        (byte) 0xA1 <= rawtext[i + 1]
                        && rawtext[i + 1] <= (byte) 0xFE) {
                    cnschars++;
                    totalfreq += 500;
                    row = rawtext[i] + 256 - 0xA1;
                    column = rawtext[i + 1] + 256 - 0xA1;
                    if (EUC_TWFreq[row][column] != 0) {
                        cnsfreq += EUC_TWFreq[row][column];
                    } else if (35 <= row && row <= 92) {
                        cnsfreq += 150;
                    }
                    i++;
                }
            }
        }

        rangeval = 50 * ((float) cnschars / (float) dbchars);
        freqval = 50 * ((float) cnsfreq / (float) totalfreq);
        //System.out.println("encoding..." + rangeval + " " + freqval);
        return (int) (rangeval + freqval + 0.5);
    }
    /**
     * initiate the frequency of euc_tw chars
     *
     */
    private static void initialize_frequencies(){
        for (int i = 0; i < 94; i++) {
            for (int j = 0; j < 94; j++) {
                EUC_TWFreq[i][j] = 0;
            }
        }
        EUC_TWFreq[48][49] = 599;
        EUC_TWFreq[35][65] = 598;
        EUC_TWFreq[41][27] = 597;
        EUC_TWFreq[35][0] = 596;
        EUC_TWFreq[39][19] = 595;
        EUC_TWFreq[35][42] = 594;
        EUC_TWFreq[38][66] = 593;
        EUC_TWFreq[35][8] = 592;
        EUC_TWFreq[35][6] = 591;
        EUC_TWFreq[35][66] = 590;
        EUC_TWFreq[43][14] = 589;
        EUC_TWFreq[69][80] = 588;
        EUC_TWFreq[50][48] = 587;
        EUC_TWFreq[36][71] = 586;
        EUC_TWFreq[37][10] = 585;
        EUC_TWFreq[60][52] = 584;
        EUC_TWFreq[51][21] = 583;
        EUC_TWFreq[40][2] = 582;
        EUC_TWFreq[67][35] = 581;
        EUC_TWFreq[38][78] = 580;
        EUC_TWFreq[49][18] = 579;
        EUC_TWFreq[35][23] = 578;
        EUC_TWFreq[42][83] = 577;
        EUC_TWFreq[79][47] = 576;
        EUC_TWFreq[61][82] = 575;
        EUC_TWFreq[38][7] = 574;
        EUC_TWFreq[35][29] = 573;
        EUC_TWFreq[37][77] = 572;
        EUC_TWFreq[54][67] = 571;
        EUC_TWFreq[38][80] = 570;
        EUC_TWFreq[52][74] = 569;
        EUC_TWFreq[36][37] = 568;
        EUC_TWFreq[74][8] = 567;
        EUC_TWFreq[41][83] = 566;
        EUC_TWFreq[36][75] = 565;
        EUC_TWFreq[49][63] = 564;
        EUC_TWFreq[42][58] = 563;
        EUC_TWFreq[56][33] = 562;
        EUC_TWFreq[37][76] = 561;
        EUC_TWFreq[62][39] = 560;
        EUC_TWFreq[35][21] = 559;
        EUC_TWFreq[70][19] = 558;
        EUC_TWFreq[77][88] = 557;
        EUC_TWFreq[51][14] = 556;
        EUC_TWFreq[36][17] = 555;
        EUC_TWFreq[44][51] = 554;
        EUC_TWFreq[38][72] = 553;
        EUC_TWFreq[74][90] = 552;
        EUC_TWFreq[35][48] = 551;
        EUC_TWFreq[35][69] = 550;
        EUC_TWFreq[66][86] = 549;
        EUC_TWFreq[57][20] = 548;
        EUC_TWFreq[35][53] = 547;
        EUC_TWFreq[36][87] = 546;
        EUC_TWFreq[84][67] = 545;
        EUC_TWFreq[70][56] = 544;
        EUC_TWFreq[71][54] = 543;
        EUC_TWFreq[60][70] = 542;
        EUC_TWFreq[80][1] = 541;
        EUC_TWFreq[39][59] = 540;
        EUC_TWFreq[39][51] = 539;
        EUC_TWFreq[35][44] = 538;
        EUC_TWFreq[48][4] = 537;
        EUC_TWFreq[55][24] = 536;
        EUC_TWFreq[52][4] = 535;
        EUC_TWFreq[54][26] = 534;
        EUC_TWFreq[36][31] = 533;
        EUC_TWFreq[37][22] = 532;
        EUC_TWFreq[37][9] = 531;
        EUC_TWFreq[46][0] = 530;
        EUC_TWFreq[56][46] = 529;
        EUC_TWFreq[47][93] = 528;
        EUC_TWFreq[37][25] = 527;
        EUC_TWFreq[39][8] = 526;
        EUC_TWFreq[46][73] = 525;
        EUC_TWFreq[38][48] = 524;
        EUC_TWFreq[39][83] = 523;
        EUC_TWFreq[60][92] = 522;
        EUC_TWFreq[70][11] = 521;
        EUC_TWFreq[63][84] = 520;
        EUC_TWFreq[38][65] = 519;
        EUC_TWFreq[45][45] = 518;
        EUC_TWFreq[63][49] = 517;
        EUC_TWFreq[63][50] = 516;
        EUC_TWFreq[39][93] = 515;
        EUC_TWFreq[68][20] = 514;
        EUC_TWFreq[44][84] = 513;
        EUC_TWFreq[66][34] = 512;
        EUC_TWFreq[37][58] = 511;
        EUC_TWFreq[39][0] = 510;
        EUC_TWFreq[59][1] = 509;
        EUC_TWFreq[47][8] = 508;
        EUC_TWFreq[61][17] = 507;
        EUC_TWFreq[53][87] = 506;
        EUC_TWFreq[67][26] = 505;
        EUC_TWFreq[43][46] = 504;
        EUC_TWFreq[38][61] = 503;
        EUC_TWFreq[45][9] = 502;
        EUC_TWFreq[66][83] = 501;
        EUC_TWFreq[43][88] = 500;
        EUC_TWFreq[85][20] = 499;
        EUC_TWFreq[57][36] = 498;
        EUC_TWFreq[43][6] = 497;
        EUC_TWFreq[86][77] = 496;
        EUC_TWFreq[42][70] = 495;
        EUC_TWFreq[49][78] = 494;
        EUC_TWFreq[36][40] = 493;
        EUC_TWFreq[42][71] = 492;
        EUC_TWFreq[58][49] = 491;
        EUC_TWFreq[35][20] = 490;
        EUC_TWFreq[76][20] = 489;
        EUC_TWFreq[39][25] = 488;
        EUC_TWFreq[40][34] = 487;
        EUC_TWFreq[39][76] = 486;
        EUC_TWFreq[40][1] = 485;
        EUC_TWFreq[59][0] = 484;
        EUC_TWFreq[39][70] = 483;
        EUC_TWFreq[46][14] = 482;
        EUC_TWFreq[68][77] = 481;
        EUC_TWFreq[38][55] = 480;
        EUC_TWFreq[35][78] = 479;
        EUC_TWFreq[84][44] = 478;
        EUC_TWFreq[36][41] = 477;
        EUC_TWFreq[37][62] = 476;
        EUC_TWFreq[65][67] = 475;
        EUC_TWFreq[69][66] = 474;
        EUC_TWFreq[73][55] = 473;
        EUC_TWFreq[71][49] = 472;
        EUC_TWFreq[66][87] = 471;
        EUC_TWFreq[38][33] = 470;
        EUC_TWFreq[64][61] = 469;
        EUC_TWFreq[35][7] = 468;
        EUC_TWFreq[47][49] = 467;
        EUC_TWFreq[56][14] = 466;
        EUC_TWFreq[36][49] = 465;
        EUC_TWFreq[50][81] = 464;
        EUC_TWFreq[55][76] = 463;
        EUC_TWFreq[35][19] = 462;
        EUC_TWFreq[44][47] = 461;
        EUC_TWFreq[35][15] = 460;
        EUC_TWFreq[82][59] = 459;
        EUC_TWFreq[35][43] = 458;
        EUC_TWFreq[73][0] = 457;
        EUC_TWFreq[57][83] = 456;
        EUC_TWFreq[42][46] = 455;
        EUC_TWFreq[36][0] = 454;
        EUC_TWFreq[70][88] = 453;
        EUC_TWFreq[42][22] = 452;
        EUC_TWFreq[46][58] = 451;
        EUC_TWFreq[36][34] = 450;
        EUC_TWFreq[39][24] = 449;
        EUC_TWFreq[35][55] = 448;
        EUC_TWFreq[44][91] = 447;
        EUC_TWFreq[37][51] = 446;
        EUC_TWFreq[36][19] = 445;
        EUC_TWFreq[69][90] = 444;
        EUC_TWFreq[55][35] = 443;
        EUC_TWFreq[35][54] = 442;
        EUC_TWFreq[49][61] = 441;
        EUC_TWFreq[36][67] = 440;
        EUC_TWFreq[88][34] = 439;
        EUC_TWFreq[35][17] = 438;
        EUC_TWFreq[65][69] = 437;
        EUC_TWFreq[74][89] = 436;
        EUC_TWFreq[37][31] = 435;
        EUC_TWFreq[43][48] = 434;
        EUC_TWFreq[89][27] = 433;
        EUC_TWFreq[42][79] = 432;
        EUC_TWFreq[69][57] = 431;
        EUC_TWFreq[36][13] = 430;
        EUC_TWFreq[35][62] = 429;
        EUC_TWFreq[65][47] = 428;
        EUC_TWFreq[56][8] = 427;
        EUC_TWFreq[38][79] = 426;
        EUC_TWFreq[37][64] = 425;
        EUC_TWFreq[64][64] = 424;
        EUC_TWFreq[38][53] = 423;
        EUC_TWFreq[38][31] = 422;
        EUC_TWFreq[56][81] = 421;
        EUC_TWFreq[36][22] = 420;
        EUC_TWFreq[43][4] = 419;
        EUC_TWFreq[36][90] = 418;
        EUC_TWFreq[38][62] = 417;
        EUC_TWFreq[66][85] = 416;
        EUC_TWFreq[39][1] = 415;
        EUC_TWFreq[59][40] = 414;
        EUC_TWFreq[58][93] = 413;
        EUC_TWFreq[44][43] = 412;
        EUC_TWFreq[39][49] = 411;
        EUC_TWFreq[64][2] = 410;
        EUC_TWFreq[41][35] = 409;
        EUC_TWFreq[60][22] = 408;
        EUC_TWFreq[35][91] = 407;
        EUC_TWFreq[78][1] = 406;
        EUC_TWFreq[36][14] = 405;
        EUC_TWFreq[82][29] = 404;
        EUC_TWFreq[52][86] = 403;
        EUC_TWFreq[40][16] = 402;
        EUC_TWFreq[91][52] = 401;
        EUC_TWFreq[50][75] = 400;
        EUC_TWFreq[64][30] = 399;
        EUC_TWFreq[90][78] = 398;
        EUC_TWFreq[36][52] = 397;
        EUC_TWFreq[55][87] = 396;
        EUC_TWFreq[57][5] = 395;
        EUC_TWFreq[57][31] = 394;
        EUC_TWFreq[42][35] = 393;
        EUC_TWFreq[69][50] = 392;
        EUC_TWFreq[45][8] = 391;
        EUC_TWFreq[50][87] = 390;
        EUC_TWFreq[69][55] = 389;
        EUC_TWFreq[92][3] = 388;
        EUC_TWFreq[36][43] = 387;
        EUC_TWFreq[64][10] = 386;
        EUC_TWFreq[56][25] = 385;
        EUC_TWFreq[60][68] = 384;
        EUC_TWFreq[51][46] = 383;
        EUC_TWFreq[50][0] = 382;
        EUC_TWFreq[38][30] = 381;
        EUC_TWFreq[50][85] = 380;
        EUC_TWFreq[60][54] = 379;
        EUC_TWFreq[73][6] = 378;
        EUC_TWFreq[73][28] = 377;
        EUC_TWFreq[56][19] = 376;
        EUC_TWFreq[62][69] = 375;
        EUC_TWFreq[81][66] = 374;
        EUC_TWFreq[40][32] = 373;
        EUC_TWFreq[76][31] = 372;
        EUC_TWFreq[35][10] = 371;
        EUC_TWFreq[41][37] = 370;
        EUC_TWFreq[52][82] = 369;
        EUC_TWFreq[91][72] = 368;
        EUC_TWFreq[37][29] = 367;
        EUC_TWFreq[56][30] = 366;
        EUC_TWFreq[37][80] = 365;
        EUC_TWFreq[81][56] = 364;
        EUC_TWFreq[70][3] = 363;
        EUC_TWFreq[76][15] = 362;
        EUC_TWFreq[46][47] = 361;
        EUC_TWFreq[35][88] = 360;
        EUC_TWFreq[61][58] = 359;
        EUC_TWFreq[37][37] = 358;
        EUC_TWFreq[57][22] = 357;
        EUC_TWFreq[41][23] = 356;
        EUC_TWFreq[90][66] = 355;
        EUC_TWFreq[39][60] = 354;
        EUC_TWFreq[38][0] = 353;
        EUC_TWFreq[37][87] = 352;
        EUC_TWFreq[46][2] = 351;
        EUC_TWFreq[38][56] = 350;
        EUC_TWFreq[58][11] = 349;
        EUC_TWFreq[48][10] = 348;
        EUC_TWFreq[74][4] = 347;
        EUC_TWFreq[40][42] = 346;
        EUC_TWFreq[41][52] = 345;
        EUC_TWFreq[61][92] = 344;
        EUC_TWFreq[39][50] = 343;
        EUC_TWFreq[47][88] = 342;
        EUC_TWFreq[88][36] = 341;
        EUC_TWFreq[45][73] = 340;
        EUC_TWFreq[82][3] = 339;
        EUC_TWFreq[61][36] = 338;
        EUC_TWFreq[60][33] = 337;
        EUC_TWFreq[38][27] = 336;
        EUC_TWFreq[35][83] = 335;
        EUC_TWFreq[65][24] = 334;
        EUC_TWFreq[73][10] = 333;
        EUC_TWFreq[41][13] = 332;
        EUC_TWFreq[50][27] = 331;
        EUC_TWFreq[59][50] = 330;
        EUC_TWFreq[42][45] = 329;
        EUC_TWFreq[55][19] = 328;
        EUC_TWFreq[36][77] = 327;
        EUC_TWFreq[69][31] = 326;
        EUC_TWFreq[60][7] = 325;
        EUC_TWFreq[40][88] = 324;
        EUC_TWFreq[57][56] = 323;
        EUC_TWFreq[50][50] = 322;
        EUC_TWFreq[42][37] = 321;
        EUC_TWFreq[38][82] = 320;
        EUC_TWFreq[52][25] = 319;
        EUC_TWFreq[42][67] = 318;
        EUC_TWFreq[48][40] = 317;
        EUC_TWFreq[45][81] = 316;
        EUC_TWFreq[57][14] = 315;
        EUC_TWFreq[42][13] = 314;
        EUC_TWFreq[78][0] = 313;
        EUC_TWFreq[35][51] = 312;
        EUC_TWFreq[41][67] = 311;
        EUC_TWFreq[64][23] = 310;
        EUC_TWFreq[36][65] = 309;
        EUC_TWFreq[48][50] = 308;
        EUC_TWFreq[46][69] = 307;
        EUC_TWFreq[47][89] = 306;
        EUC_TWFreq[41][48] = 305;
        EUC_TWFreq[60][56] = 304;
        EUC_TWFreq[44][82] = 303;
        EUC_TWFreq[47][35] = 302;
        EUC_TWFreq[49][3] = 301;
        EUC_TWFreq[49][69] = 300;
        EUC_TWFreq[45][93] = 299;
        EUC_TWFreq[60][34] = 298;
        EUC_TWFreq[60][82] = 297;
        EUC_TWFreq[61][61] = 296;
        EUC_TWFreq[86][42] = 295;
        EUC_TWFreq[89][60] = 294;
        EUC_TWFreq[48][31] = 293;
        EUC_TWFreq[35][75] = 292;
        EUC_TWFreq[91][39] = 291;
        EUC_TWFreq[53][19] = 290;
        EUC_TWFreq[39][72] = 289;
        EUC_TWFreq[69][59] = 288;
        EUC_TWFreq[41][7] = 287;
        EUC_TWFreq[54][13] = 286;
        EUC_TWFreq[43][28] = 285;
        EUC_TWFreq[36][6] = 284;
        EUC_TWFreq[45][75] = 283;
        EUC_TWFreq[36][61] = 282;
        EUC_TWFreq[38][21] = 281;
        EUC_TWFreq[45][14] = 280;
        EUC_TWFreq[61][43] = 279;
        EUC_TWFreq[36][63] = 278;
        EUC_TWFreq[43][30] = 277;
        EUC_TWFreq[46][51] = 276;
        EUC_TWFreq[68][87] = 275;
        EUC_TWFreq[39][26] = 274;
        EUC_TWFreq[46][76] = 273;
        EUC_TWFreq[36][15] = 272;
        EUC_TWFreq[35][40] = 271;
        EUC_TWFreq[79][60] = 270;
        EUC_TWFreq[46][7] = 269;
        EUC_TWFreq[65][72] = 268;
        EUC_TWFreq[69][88] = 267;
        EUC_TWFreq[47][18] = 266;
        EUC_TWFreq[37][0] = 265;
        EUC_TWFreq[37][49] = 264;
        EUC_TWFreq[67][37] = 263;
        EUC_TWFreq[36][91] = 262;
        EUC_TWFreq[75][48] = 261;
        EUC_TWFreq[75][63] = 260;
        EUC_TWFreq[83][87] = 259;
        EUC_TWFreq[37][44] = 258;
        EUC_TWFreq[73][54] = 257;
        EUC_TWFreq[51][61] = 256;
        EUC_TWFreq[46][57] = 255;
        EUC_TWFreq[55][21] = 254;
        EUC_TWFreq[39][66] = 253;
        EUC_TWFreq[47][11] = 252;
        EUC_TWFreq[52][8] = 251;
        EUC_TWFreq[82][81] = 250;
        EUC_TWFreq[36][57] = 249;
        EUC_TWFreq[38][54] = 248;
        EUC_TWFreq[43][81] = 247;
        EUC_TWFreq[37][42] = 246;
        EUC_TWFreq[40][18] = 245;
        EUC_TWFreq[80][90] = 244;
        EUC_TWFreq[37][84] = 243;
        EUC_TWFreq[57][15] = 242;
        EUC_TWFreq[38][87] = 241;
        EUC_TWFreq[37][32] = 240;
        EUC_TWFreq[53][53] = 239;
        EUC_TWFreq[89][29] = 238;
        EUC_TWFreq[81][53] = 237;
        EUC_TWFreq[75][3] = 236;
        EUC_TWFreq[83][73] = 235;
        EUC_TWFreq[66][13] = 234;
        EUC_TWFreq[48][7] = 233;
        EUC_TWFreq[46][35] = 232;
        EUC_TWFreq[35][86] = 231;
        EUC_TWFreq[37][20] = 230;
        EUC_TWFreq[46][80] = 229;
        EUC_TWFreq[38][24] = 228;
        EUC_TWFreq[41][68] = 227;
        EUC_TWFreq[42][21] = 226;
        EUC_TWFreq[43][32] = 225;
        EUC_TWFreq[38][20] = 224;
        EUC_TWFreq[37][59] = 223;
        EUC_TWFreq[41][77] = 222;
        EUC_TWFreq[59][57] = 221;
        EUC_TWFreq[68][59] = 220;
        EUC_TWFreq[39][43] = 219;
        EUC_TWFreq[54][39] = 218;
        EUC_TWFreq[48][28] = 217;
        EUC_TWFreq[54][28] = 216;
        EUC_TWFreq[41][44] = 215;
        EUC_TWFreq[51][64] = 214;
        EUC_TWFreq[47][72] = 213;
        EUC_TWFreq[62][67] = 212;
        EUC_TWFreq[42][43] = 211;
        EUC_TWFreq[61][38] = 210;
        EUC_TWFreq[76][25] = 209;
        EUC_TWFreq[48][91] = 208;
        EUC_TWFreq[36][36] = 207;
        EUC_TWFreq[80][32] = 206;
        EUC_TWFreq[81][40] = 205;
        EUC_TWFreq[37][5] = 204;
        EUC_TWFreq[74][69] = 203;
        EUC_TWFreq[36][82] = 202;
        EUC_TWFreq[46][59] = 201;
    }
}
