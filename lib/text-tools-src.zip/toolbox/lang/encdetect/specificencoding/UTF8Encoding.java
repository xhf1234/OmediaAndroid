/*
 * Copyright (c) 2005, Yitao Duan, Jimmy Su, Feng Zhou and Li Zhuang Created on
 * Aug 21, 2005
 */

package toolbox.lang.encdetect.specificencoding;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import toolbox.lang.encdetect.Encoding;

/**
 * utf8 can express many languages,UTF8Encoding
 * 
 * @author ET,xudq
 */

public class UTF8Encoding implements Encoding {

    public final String getName() {
        return "UTF-8";
    }

    public final int probability(byte[] rawtext, int offset, int size,
            int checkLength) {
        int score = 0;
        int goodbytes = 0, asciibytes = 0;

        // Maybe also use UTF8 Byte Order Mark: EF BB BF

        // Check to see if characters fit into acceptable ranges
        int end = offset + size;
        for (int i = offset; i < end; i++) {
            if ((rawtext[i] & (byte) 0x7F) == rawtext[i]) { // One byte
                asciibytes++;
                // Ignore ASCII, can throw off count
            } else if (-64 <= rawtext[i] && rawtext[i] <= -33
                    && // Two bytes
                    i + 1 < end && -128 <= rawtext[i + 1]
                    && rawtext[i + 1] <= -65) {
                goodbytes += 2;
                i++;
            } else if (-32 <= rawtext[i]
                    && rawtext[i] <= -17
                    && // Three bytes
                    i + 2 < end && -128 <= rawtext[i + 1]
                    && rawtext[i + 1] <= -65 && -128 <= rawtext[i + 2]
                    && rawtext[i + 2] <= -65) {
                goodbytes += 3;
                i += 2;
            }
        }

        if (asciibytes == size) {
            return 0;
        }

        score = (int) (100 * ((float) goodbytes / (float) (size - asciibytes)));
        // System.out.println("rawtextlen " + rawtextlen + " goodbytes " +
        // goodbytes + " asciibytes " + asciibytes + " score " + score);

        // If not above 98, reduce to zero to prevent coincidental matches
        // Allows for some (few) bad formed sequences
        if (score > 98) {
            return score;
        } else if (score > 95 && goodbytes > 30) {
            return score;
        } else {
            return 0;
        }
    }

    public static void main(String[] args) throws IOException {
        if (args.length < 1) {
            System.out.println("Usage: UTF8Encoding filename [numbytes]");
            System.exit(1);
        }

        File file = new File(args[0]);
        FileInputStream stream = new FileInputStream(file);

        int len = 100000;
        if (args.length > 1) {
            try {
                len = Integer.parseInt(args[1]);
            } catch (NumberFormatException e) {}
        }

        len = Math.min(len, (int) file.length());

        byte[] rawtext = new byte[len];
        stream.read(rawtext, 0, len);
        stream.close();
        UTF8Encoding encoding = new UTF8Encoding();
        System.out.println("File: " + file + ". Examined " + len + " bytes. "
                + encoding + " probability: "
                + encoding.probability(rawtext, 0, rawtext.length, len));
    }
}
