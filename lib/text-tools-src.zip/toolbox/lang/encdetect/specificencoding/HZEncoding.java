/*
 * Copyright (c) 2005, Yitao Duan, Jimmy Su, Feng Zhou and Li Zhuang Created on
 * Aug 21, 2005
 */
package toolbox.lang.encdetect.specificencoding;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import toolbox.lang.encdetect.Encoding;

/**
 * Chinese, HZEncoding
 * 
 * @author ET,xudq
 */

public class HZEncoding implements Encoding {
    // HZ uses GB's frequency table

    public final String getName() {
        return "OTHER";
    }

    /*
     * Argument: byte array 
     * Returns : number from 0 to 100 representing probability
     *  text in array uses HZ encoding
     */
    public final int probability(byte[] rawtext, int offset, int size,
            int checkLength) {
        int hzchars = 0, dbchars = 1;
        long hzfreq = 0, totalfreq = 1;
        float rangeval = 0, freqval = 0;
        int hzstart = 0, hzend = 0;
        int row, column;

        int end = offset + size;
        for (int i = offset; i < end - 1; i++) {
            if (rawtext[i] == '~') {
                if (rawtext[i + 1] == '{') {
                    hzstart++;
                    i += 2;
                    while (i < end - 1) {
                        if (rawtext[i] == 0x0A || rawtext[i] == 0x0D) {
                            break;
                        } else if (rawtext[i] == '~' && rawtext[i + 1] == '}') {
                            hzend++;
                            i++;
                            break;
                        } else if ((0x21 <= rawtext[i] && rawtext[i] <= 0x77)
                                && (0x21 <= rawtext[i + 1] && rawtext[i + 1] <= 0x77)) {
                            hzchars += 2;
                            row = rawtext[i] - 0x21;
                            column = rawtext[i + 1] - 0x21;
                            totalfreq += 500;
                            if (GB2312Encoding.GBFreq[row][column] != 0) {
                                hzfreq += GB2312Encoding.GBFreq[row][column];
                            } else if (15 <= row && row < 55) {
                                hzfreq += 200;
                            }
                        } else if ((0xA1 <= rawtext[i] && rawtext[i] <= 0xF7)
                                && (0xA1 <= rawtext[i + 1] && rawtext[i + 1] <= 0xF7)) {
                            hzchars += 2;
                            row = rawtext[i] + 256 - 0xA1;
                            column = rawtext[i + 1] + 256 - 0xA1;
                            totalfreq += 500;
                            if (GB2312Encoding.GBFreq[row][column] != 0) {
                                hzfreq += GB2312Encoding.GBFreq[row][column];
                            } else if (15 <= row && row < 55) {
                                hzfreq += 200;
                            }
                        }
                        dbchars += 2;
                        if (dbchars >= checkLength) {
                            break;
                        }
                        i += 2;
                        i += 2;
                    }
                } else if (rawtext[i + 1] == '}') {
                    hzend++;
                    i++;
                } else if (rawtext[i + 1] == '~') {
                    i++;
                }
            }
        }

        if (hzstart > 4) {
            rangeval = 50;
        } else if (hzstart > 1) {
            rangeval = 41;
        } else if (hzstart > 0) { // Only 39 in case the sequence happened to
            // occur
            rangeval = 39; // in otherwise non-Hz text
        } else {
            rangeval = 0;
        }
        freqval = 50 * ((float) hzfreq / (float) totalfreq);

        return (int) (rangeval + freqval + 0.5);
    }

    public static void main(String[] args) throws IOException {
        if (args.length < 1) {
            System.out.println("Usage: HZEncoding filename [numbytes]");
            System.exit(1);
        }

        File file = new File(args[0]);
        FileInputStream stream = new FileInputStream(file);

        int len = 100000;
        if (args.length > 1) {
            try {
                len = Integer.parseInt(args[1]);
            } catch (NumberFormatException e) {}
        }

        len = Math.min(len, (int) file.length());

        byte[] rawtext = new byte[len];
        stream.read(rawtext, 0, len);
        stream.close();
        HZEncoding encoding = new HZEncoding();
        System.out.println("File: " + file + ". Examined " + len + " bytes. "
                + encoding.getName() + " probability: "
                + encoding.probability(rawtext, 0, rawtext.length, len));
    }
}
