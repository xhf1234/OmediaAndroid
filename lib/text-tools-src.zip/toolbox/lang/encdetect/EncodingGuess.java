/*
 * Copyright (c) 2005, Yitao Duan, Jimmy Su, Feng Zhou and Li Zhuang Created on
 * Aug 21, 2005
 */
package toolbox.lang.encdetect;

/**
 * An ecoding guess.
 * 
 * @author ET ,xudq
 */

public class EncodingGuess implements Comparable {
    /**
     * the name of guessed encoding
     */
    public String name;

    /**
     * the probability of guessed encoding
     */
    public int probability;

    /**
     * the original charset of html pages,it exists in Meta information
     */
    public String declaredCharset = null;

    public EncodingGuess(String name, int probability, String originalCharset) {
        this.name = name;
        this.probability = probability;
        this.declaredCharset = originalCharset;
    }

    public int compareTo(Object o) {
        EncodingGuess eg = (EncodingGuess) o;

        if (this.probability > eg.probability)
            return -1;
        else if (this.probability < eg.probability)
            return 1;

        return this.name.compareTo(eg.name);
    }

    public String toString() {
        return name + " (" + probability + ")with declared charset:" + declaredCharset;
    }
}
