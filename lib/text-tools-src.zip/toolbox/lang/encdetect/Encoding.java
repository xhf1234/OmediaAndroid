/*
 * Copyright (c) 2005,
 *  Yitao Duan, Jimmy Su, Feng Zhou and Li Zhuang
 *
 * Created on Aug 21, 2005
 */
package toolbox.lang.encdetect;

/** 
 * An encoding. To be extended by specific encoding (e.g. GB2313) and 
 * used together with an encoding detector.
 *
 * @author ET 
 */

public interface Encoding {
	
	/**
	 * Given some bytes, calculate the probability that they
	 * use this encoding. At most maxlen bytes will be examined. 
	 */
	public int probability(byte[] data, int offset, int size, int checkLength);
	
	public String getName();

}
