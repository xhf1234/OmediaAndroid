package toolbox.lang.encdetect;

import java.util.HashMap;

/**
 * An enumeration of encodings
 * 
 */
public class Encodings {
    public static final int GB2312 = 0;

    public static final int GBK = GB2312 + 1;

    public static final int HZ = GBK + 1;

    public static final int BIG5 = HZ + 1;

    public static final int EUC_TW = BIG5 + 1;

    public static final int ISO_2022_CN = EUC_TW + 1;

    public static final int UTF8 = ISO_2022_CN + 1;

    public static final int UNICODE = UTF8 + 1;

    public static final int EUC_KR = UNICODE + 1;

    public static final int CP949 = EUC_KR + 1;

    /*
     * we do not detect JOHAB encoding
     */
    public static final int JOHAB = CP949 + 1;

    public static final int ISO_2022_KR = JOHAB + 1;

    public static final int ASCII = ISO_2022_KR + 1;

    public static final int SJIS = ASCII + 1;

    public static final int EUC_JP = SJIS + 1;

    public static final int ISO_2022_JP = EUC_JP + 1;

    /**
     * we do not detect UNICODET encoding
     */
    public static final int UNICODET = ISO_2022_JP + 1;

    /**
     * we do not detect UNICODET encoding
     */
    public static final int UNICODES = UNICODET + 1;

    /**
     * we do not detect UNICODET encoding
     */
    public static final int ISO_2022_CN_GB = UNICODES + 1;

    /**
     * we do not detect UNICODET encoding
     */
    public static final int ISO_2022_CN_CNS = ISO_2022_CN_GB + 1;

    public static final int OTHER = ISO_2022_CN_CNS + 1;

    public static final int TOTALTYPES = OTHER + 1;

    public static String[] codings = new String[TOTALTYPES];
    static {
        codings[GB2312] = "GBK";
        codings[GBK] = "GBK";
        // java not support HZ
        codings[HZ] = "OTHER";
        codings[BIG5] = "BIG5";
        codings[EUC_TW] = "EUC-TW";// "CNS11643";
        codings[ISO_2022_CN] = "ISO-2022-CN";
        codings[UTF8] = "UTF-8";
        codings[UNICODE] = "UNICODE";

        codings[EUC_KR] = "EUC-KR";
        codings[CP949] = "CP949";

        // do not detect
        codings[JOHAB] = "OTHER";

        codings[ISO_2022_KR] = "ISO-2022-KR";

        codings[ASCII] = "ISO-8859-1";

        codings[SJIS] = "Shift_JIS";
        codings[EUC_JP] = "EUC-JP";
        codings[ISO_2022_JP] = "ISO-2022-JP";

        // do not detect the list
        codings[UNICODET] = "OTHER";
        codings[UNICODES] = "OTHER";
        codings[ISO_2022_CN_GB] = "OTHER";
        codings[ISO_2022_CN_CNS] = "OTHER";

        codings[OTHER] = "OTHER";
    }


    /**
     * A map from commonly-seen encoding alias to its canonical name used in our
     * system. This table contains only Chinese encodings that we support. If in
     * the future for some reason non-Chinese encodings are added to the table,
     * remember to modifiy the last line of method nonChinese().
     */

    private static HashMap<String, String> encodingCanonicalNames = new HashMap<String, String>();

    static {
        encodingCanonicalNames.put("cn-gb2312-80", "GB2312");
        encodingCanonicalNames.put("gb_2312-80", "GB2312");
        encodingCanonicalNames.put("gb2312", "GB2312");
        encodingCanonicalNames.put("gbk", "GBK");
        encodingCanonicalNames.put("big5", "BIG5");
        encodingCanonicalNames.put("big-5", "BIG5");
        encodingCanonicalNames.put("utf8", "UTF-8");
        encodingCanonicalNames.put("utf-8", "UTF-8");
        encodingCanonicalNames.put("utf8", "UTF-8");
        encodingCanonicalNames.put("x-x-big5", "BIG5");
        encodingCanonicalNames.put("x-euc-cn", "GB18030");
    }

    public static String resolveEncodingCanonicalName(String encoding) {
        return encodingCanonicalNames.get(encoding.toLowerCase());
    }

}
