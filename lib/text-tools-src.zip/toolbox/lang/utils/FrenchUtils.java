package toolbox.lang.utils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashSet;

import toolbox.lang.LanguageConsts;
import toolbox.lang.LanguageDetector;

/**
 * 法语语言检测工具
 * 
 * @author liq
 */
public class FrenchUtils implements LanguageUtils {

    private static HashSet<String> frenchCommonWords = new HashSet<String>();

    static {
        // 导入法语常见词
        InputStream is = FrenchUtils.class.getResourceAsStream("frDict");
        if (is == null) {
            throw new RuntimeException("cannot find frDict in classpath");
        } else {
            try {
                try {
                    BufferedReader br = new BufferedReader(new InputStreamReader(is,
                            "utf-8"));
                    String line;
                    while ((line = br.readLine()) != null) {
                        frenchCommonWords.add(line);
                    }
                } finally {
                    is.close();
                }
            } catch (IOException e) {
                throw new RuntimeException("load frDict failed", e);
            }
        }
    }

    @Override
    public byte getLanguageType() {
        return LanguageConsts.LANG_FR;
    }

    @Override
    public boolean hit(CharSequence sentence, int[] counts, double[] other) {
        // 判断是否是法语
        double frenchLetter = (double) (counts[LanguageDetector.CT_FRENCH_LATIN] + counts[LanguageDetector.CT_ASCII])
                / (double) counts[LanguageDetector.CT_NONWHITESPACE];
        double western = other[LanguageDetector.OTHER_WESTERN_WORD]
                          / (other[LanguageDetector.OTHER_WESTERN_WORD] + other[LanguageDetector.OTHER_EAST_ASIAN_WORD]);

        // 判断法文字符占的比例
        if (western > 0.95 && frenchLetter > 0.5) {
            double notFrenchLatin = (double) (counts[LanguageDetector.CT_LATIN] - counts[LanguageDetector.CT_FRENCH_LATIN])
                    / (double) counts[LanguageDetector.CT_NONWHITESPACE];
            // 如果非法文中的拉丁过多则跳过
            if (notFrenchLatin <= 0.01) {
                double frenchLatin = (double) counts[LanguageDetector.CT_FRENCH_LATIN]
                        / (double) counts[LanguageDetector.CT_FRENCH_LETTER];
                if (frenchLatin > 0.04)
                    return true;
                long wordCount = 0, frenchCommonWordCount = 0;
                int i = 0;
                sentence = toLower(sentence);
                int startPos, endPos;
                char c;
                // 根据法文常见词来判断
                while (i < sentence.length()) {
                    while (i < sentence.length()
                            && !isFrenchLetter(sentence.charAt(i))) {
                        i++;
                    }
                    startPos = i;
                    while (i < sentence.length()
                            && isFrenchLetter(sentence.charAt(i))) {
                        i++;
                    }
                    endPos = i;
                    if (startPos == endPos)
                        break;
                    
                    //判断单词两端是否是数字，连接符和下划线
                    //如果是则不认为是一个单词，跳过
                    if (startPos >= 1){
                        c = sentence.charAt(startPos - 1);
                        if (c >= '0' && c <= '9' || c == '-' || c == '_')
                            continue;
                    }
                    if (endPos < sentence.length()){
                        c = sentence.charAt(endPos);
                        if (c >= '0' && c <= '9' || c == '-' || c == '_')
                            continue;
                    }
                    
                    wordCount++;
                    if (frenchCommonWords.contains(sentence.subSequence(startPos, endPos)))
                        frenchCommonWordCount++;
                }
                // 常见词占所有词的比例
                double frenchCommon = (double) frenchCommonWordCount
                        / (double) wordCount;
                if (frenchLatin > 0.01 && frenchCommonWordCount > 0
                        || frenchCommon > 0.25)
                    return true;
            }
        }
        return false;
    }

    // 判断是否是法语字符
    public static boolean isFrenchLetter(char c) {
        if (c >= 'A' && c <= 'Z')
            return true;
        if (c >= 'a' && c <= 'z')
            return true;
        if (isFrenchLatin(c))
            return true;
        return false;
    }

    // 判断是否是非法语拉丁
    public static boolean isNotFrenchLatin(char c) {
        return c >= 0xC0 && c <= 0xFF && !isFrenchLatin(c);
    }

    // 判断是否是法语拉丁
    public static boolean isFrenchLatin(char c) {
        if (c == 0xC0 || c == 0xE0 || c == 0xC2 || c == 0xE2 || c >= 0xC7
                && c <= 0xCB || c >= 0xE7 && c <= 0xEB || c == 0xCE
                || c == 0xEE || c == 0xCF || c == 0xEF || c == 0xD4
                || c == 0xF4 || c == 0xD9 || c == 0xF9 || c == 0xDB
                || c == 0xFB || c == 0x152 || c == 0x153)
            return true;
        return false;
    }
    
    //转大写为小写
    private static CharSequence toLower(CharSequence s) {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c >= 'A' && c <= 'Z' || c >= 0xC0 && c <= 0xDF)
                c = (char) (c + 32);
            else if (c == 0x152)
                c = (char) 0x153;
            sb.append(c);
        }
        return sb.toString();
    }
}
