package toolbox.lang.utils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;

import toolbox.lang.LanguageConsts;
import toolbox.lang.LanguageDetector;

/**
 * 日语语言检测工具
 * 
 * @author liq
 */
public class JapaneseUtils implements LanguageUtils {

    // 日文中常见汉字
    private static char[] codeList;

    // 日文中常见汉字得分
    private static double[] codeScore;

    static {
        // 初始化读入日文中常见汉字以及得分
        InputStream is = JapaneseUtils.class.getResourceAsStream("kanjiScore");
        if (is == null) {
            throw new RuntimeException("cannot find kanjiScore in classpath");
        } else {
            try {
                try {
                    BufferedReader br = new BufferedReader(new InputStreamReader(is, "utf-8"));
                    StringBuffer sb = new StringBuffer();
                    String line;
                    ArrayList<String> list = new ArrayList<String>();
                    while ((line = br.readLine()) != null) {
                        list.add(line);
                    }
                    codeScore = new double[list.size()];
                    for (int i = 0; i < list.size(); i++) {
                        codeScore[i] = Double.parseDouble(list.get(i).substring(2,
                                list.get(i).length()));
                        sb.append(list.get(i).charAt(0));
                    }
                    codeList = sb.toString().toCharArray();
                } finally {
                    is.close();
                }
            } catch (IOException e) {
                throw new RuntimeException("load kanjiScore failed", e);
            }
        }
    }

    @Override
    public byte getLanguageType() {
        return LanguageConsts.LANG_JP;
    }

    @Override
    public boolean hit(CharSequence sentence, int[] counts, double[] other) {
        // 判断是否是日文
        double jp = ((double) (counts[LanguageDetector.CT_KANJI] + counts[LanguageDetector.CT_KANA]))
                / counts[LanguageDetector.CT_EAST_ASIAN];
        if (jp >= 0.5) {
            double japaneseChar = ((double) counts[LanguageDetector.CT_KANA] + (double) counts[LanguageDetector.CT_KANJI_J])
                    / (double) counts[LanguageDetector.CT_EAST_ASIAN];
            if (japaneseChar > 0.2)
                return true;
            if (other[LanguageDetector.OTHER_SCORE_J] > other[LanguageDetector.OTHER_SCORE_C]
                && counts[LanguageDetector.CT_KANA] + counts[LanguageDetector.CT_KANJI_J] > 0)
                return true;
        }
        return false;
    }

    public static double getScore(char c) {
        int i = Arrays.binarySearch(codeList, c);
        if (i >= 0)
            return codeScore[i];
        else
            return -1;
    }
}
