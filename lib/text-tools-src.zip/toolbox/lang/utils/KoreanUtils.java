package toolbox.lang.utils;

import toolbox.lang.LanguageConsts;
import toolbox.lang.LanguageDetector;

/**
 * 韩语语言检测工具
 * 
 * @author liq
 */
public class KoreanUtils implements LanguageUtils {

    @Override
    public byte getLanguageType() {
        return LanguageConsts.LANG_KR;
    }

    @Override
    public boolean hit(CharSequence sentence, int[] counts, double[] scores) {
        //判断是否是韩文
        double kr = ((double) counts[LanguageDetector.CT_KOREAN])
                / counts[LanguageDetector.CT_EAST_ASIAN];
        if (kr > 0.9) {
            return true;
        }
        return false;
    }
}
