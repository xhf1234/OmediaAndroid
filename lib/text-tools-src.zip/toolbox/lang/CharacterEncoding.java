/**
 * @(#)UrlCharacterEncoding.java, 2007-6-24. 
 * 
 * Copyright 2007 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.lang;

/**
 * Identify the character encoding by one int.
 * @author river
 *
 */
public class CharacterEncoding {

    /**
     * UTF-8 encoding.
     */
    public static final int ENCODING_UTF8 = 0;
    
    /**
     * GBK encoding.
     */
    public static final int ENCODING_GBK = 1;
    
    /**
     * Use the encoding of parent.
     */
    public static final int ENCODING_FOLLOW_PARENT = 2;
    
    /**
     * Unknown encoding.
     */
    public static final int ENCODING_UNKNOWN = -1;
    
    /**
     * Return the code of encoding.
     * @param s
     * @return
     */
    public static int getEncoding(String s) {
        if (s.equalsIgnoreCase("utf-8") || s.equalsIgnoreCase("utf8")) {
            return ENCODING_UTF8;
        } else if (s.equalsIgnoreCase("gbk")) {
            return ENCODING_GBK;
        } else if (s.equalsIgnoreCase("parent")) {
            return ENCODING_FOLLOW_PARENT;
        } else {
            return ENCODING_UNKNOWN;
        }
    }
    
    /**
     * 返回encoding的code所对应的字符集的名字.
     * @param encoding
     * @return
     */
    public static final String getEncodingName(int encoding) {
        switch(encoding) {
        case ENCODING_UTF8 : return "UTF-8";
        case ENCODING_GBK : return "GBK";
        case ENCODING_FOLLOW_PARENT : return "PARENT";
        default : return "UNKNOWN";
        }
    }
    
}
