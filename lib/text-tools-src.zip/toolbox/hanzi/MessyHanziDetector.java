package toolbox.hanzi;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashSet;

import toolbox.lang.ChnConstant;


/**
 * 判断一段文本是否存在乱码
 * 
 * 有两组方法供使用：
 * (1) detect()
 *     检测一段文本的类型，所返回int值表示该文本的类型（详见各文本类型定义）。
 * (2) computeConfidence()
 *     计算一段文本为正常汉字文本的可信度，如无法判定将返回UNDECIDABLE_CONFIDENCE。
 *     调用getMinConfidence()可取得建议的最低可信度值。
 *     
 * @author Li Fei
 */
public class MessyHanziDetector {
    /**
     * 文本类型: 无汉字文本
     * 指不包含任何汉字的文本。
     */
    public static final int NO_HANZI_TEXT = 1;

    /**
     * 文本类型: 日文文本
     */
    public static final int JAPANESE_TEXT = 2;

    /**
     * 文本类型: 正常汉字文本
     * 指基本没有乱码的正常汉字文本
     */
    public static final int NOMAL_HANZI_TEXT = 3;

    /**
     * 文本类型: 低频汉字文本
     * 指包含大量低频汉字的文本，但不属于乱码文本
     */
    public static final int LOW_FREQ_HANZI_TEXT = 4;

    /**
     * 文本类型: 混合乱码文本
     * 指字母文本中夹杂乱码，如：膍while 泼there 糥are 徾卜蔹user
     */
    public static final int MIXED_MESS_TEXT = 5;

    /**
     * 文本类型: 部分乱码文本
     * 指文本中部分有乱码，部分是正常汉字文本
     */
    public static final int PARTIAL_MESS_TEXT = 6;

    /**
     * 文本类型: 全部乱码文本
     * 指文本基本都是乱码
     */
    public static final int TOTAL_MESS_TEXT = 7;

    /**
     * 无法判定类型的文本的可信度取值
     */
    public static final float UNDECIDABLE_CONFIDENCE = -1;

    private static HashSet<Char> highFreqHanzi;
    private static boolean isWorkable = false;
    static {
        highFreqHanzi = new HashSet<Char>();

        InputStream is = MessyHanziDetector.class.getResourceAsStream(
                "hanzistat.properties");
        if (is == null) {
            System.out.println("Cannot find hanzi statistics in classpath!");
        } else {
            try {
                try {
                    loadHighFreqHanzi(is);
                    isWorkable = true;
                } finally {
                    is.close();
                }
            } catch(IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Mininum confidence for normal Hanzi text
     */
    private static final float minConfidence = 0.9f;

    /**
     * Return the minimum confidence for normal text
     * 
     * @return  a value of type <code>float</code> representing minimum
     *         confidence of normal text
     */
    public static float getMinConfidence() {
        return minConfidence;
    }

    /**
     * Constructor
     * 
     * @exception IllegalStateException  if resources cannot be loaded
     * 
     */
    public MessyHanziDetector() {
        if (!isWorkable) {
            throw new IllegalStateException(
                    "MessyHanziDetector initialization failed!");
        }
    }

    /**
     * Detect type of text
     * 
     * @param   text   text to be detected
     * @return  a value of type <code>int</code> representing text type
     * @see     MessyHanziDetector#NO_HANZI_TEXT
     * @see     MessyHanziDetector#JAPANESE_TEXT
     * @see     MessyHanziDetector#NOMAL_HANZI_TEXT
     * @see     MessyHanziDetector#LOW_FREQ_HANZI_TEXT
     * @see     MessyHanziDetector#MIXED_MESS_TEXT
     * @see     MessyHanziDetector#PARTIAL_MESS_TEXT
     * @see     MessyHanziDetector#TOTAL_MESS_TEXT
     */
    public int detect(String text) {
        char[] chars = text.toCharArray();
        return detect(chars, 0, chars.length);
    }

    /**
     * Detect type of text
     * 
     * @param   buf      buffer of text to be detected
     * @return  a value of type <code>int</code> representing text type
     * @see     MessyHanziDetector#NO_HANZI_TEXT
     * @see     MessyHanziDetector#JAPANESE_TEXT
     * @see     MessyHanziDetector#NOMAL_HANZI_TEXT
     * @see     MessyHanziDetector#LOW_FREQ_HANZI_TEXT
     * @see     MessyHanziDetector#MIXED_MESS_TEXT
     * @see     MessyHanziDetector#PARTIAL_MESS_TEXT
     * @see     MessyHanziDetector#TOTAL_MESS_TEXT
     */
    public int detect(char[] buf) {
        return detect(buf, 0, buf.length);
    }

    /*
     * Mininum ratio of Japaness char to hanzi in Japanese text
     */
    private static final float minRatioOfJpCharToHanzi = 0.4f;
    /*
     * Mininum ratio of letter to hanzi in western text (e.g. English, French)
     */
    private static final float minRatioOfLetterToHanzi = 2;
    /*
     * Mininum ratio of bad char to hanzi in messy-code text
     */
    private static final float minRatioOfBadCharToHanzi = 0.05f;
    /*
     * Mininum percent of partial mess text
     */
    private static final float minPartialMessTextPercent = 0.3f;
    /*
     * Maximum percent of partial mess text
     */
    private static final float maxPartialMessTextPercent = 0.6f;

    /**
     * Detect type of text
     * 
     * @param   buf      buffer of text to be detected
     * @param   offset   the initial offset of text
     * @param   count    the length of the text
     * @return  a value of type <code>int</code> representing text type
     * @see     MessyHanziDetector#NO_HANZI_TEXT
     * @see     MessyHanziDetector#JAPANESE_TEXT
     * @see     MessyHanziDetector#NOMAL_HANZI_TEXT
     * @see     MessyHanziDetector#LOW_FREQ_HANZI_TEXT
     * @see     MessyHanziDetector#MIXED_MESS_TEXT
     * @see     MessyHanziDetector#PARTIAL_MESS_TEXT
     * @see     MessyHanziDetector#TOTAL_MESS_TEXT
     * @exception IllegalArgumentException  if <code>offset</code> is
     *          negative, or <code>count</code> is negative.
     */
    public int detect(char[] buf, int offset, int count) {
        if (offset < 0) {
            throw new IllegalArgumentException(
                    "\"offset\" cannot be a negative!");
        }
        if (count < 0) {
            throw new IllegalArgumentException(
                    "\"count\" cannot be a negative!");
        }

        int badCharCount = 0, jpCharCount = 0, letterCount = 0;
        int hanziCount = 0, hanziInspected = 0, highFreqInspected = 0;

        Char c = new Char();
        int pos = offset;
        int end = (pos + count) > buf.length ? buf.length : (pos + count);
        while (pos < end) {
            /*
             * get block statistics
             * blocks are separated by line separators or paragraph separators
             */
            int badChar = 0, jpChar = 0, letter = 0;
            int hanzi = 0, highFreq = 0;
            for (boolean inBlock = true; inBlock && (pos < end); pos++) {
                char ch = buf[pos];
                int type = Character.getType(ch);
                switch (type) {
                    case Character.OTHER_LETTER:
                        if (ChnConstant.isChineseChar(ch)) {
                            ++hanzi;
                            c.set(ch);
                            if (highFreqHanzi.contains(c)) {
                                ++highFreq;
                            }
                        } else if (ChnConstant.isJapaneseChar(ch)) {
                            ++jpChar;
                        }
                        break;
                    case Character.UPPERCASE_LETTER:
                    case Character.LOWERCASE_LETTER:
                        ++letter;
                        break;
                    case Character.CONTROL:
                        if (ch == '\n') {
                            inBlock = false;
                        }
                        break;
                    case Character.LINE_SEPARATOR:
                    case Character.PARAGRAPH_SEPARATOR:
                        inBlock = false;
                        break;
                    case Character.PRIVATE_USE:
                        ++badChar;
                        break;
                    case Character.OTHER_SYMBOL:
                        if (ch == '\uFFFD') {
                            ++badChar;
                        }
                        break;
                    default:
                        ;
                }
            } /* for () */

            if (hanzi > 0) {
                hanziCount += hanzi;
                badCharCount += badChar;
                jpCharCount += jpChar;
                letterCount += letter;

                /* skip block with high confidence */
                if (highFreq < hanzi) {
                    hanziInspected += hanzi;
                    highFreqInspected += highFreq;
                }
            }
        } /* while (pos < end) */

        if (hanziCount == 0) {
            /* no hanzi */
            return NO_HANZI_TEXT;
        }

        /* test whether it is Japanese text */
        float j2h = (float)jpCharCount / (float)hanziCount;
        if (j2h >= minRatioOfJpCharToHanzi) {
            /* Japanese text */
            return JAPANESE_TEXT;
        }

        if (hanziInspected == 0) {
            /* no blocks with low confidence */
            return NOMAL_HANZI_TEXT;
        }

        /* compute confidence */
        float confidence = (float)highFreqInspected / (float)hanziInspected;
        float percent = (float)hanziInspected / (float)hanziCount;
        if (percent < minPartialMessTextPercent) {
            /*
             * to adjust confidence when the percent of possible messy text  
             * does not reach minMessyTextPercent
             */
            confidence = confidence * percent + (1 - percent);
        }

        /* test whether it is western text */
        float l2h = (float)letterCount / (float)hanziCount;
        if (l2h >= minRatioOfLetterToHanzi) {
            return (confidence < minConfidence) ?
                    MIXED_MESS_TEXT : NOMAL_HANZI_TEXT;
        }

        /*  messy-code text usually contains bad characters */
        if (confidence < minConfidence) {
            int minBadCharCount =
                (int)(minRatioOfBadCharToHanzi * hanziCount) + 1;
            if (badCharCount < minBadCharCount) {
                /*
                 * few or no bad characters
                 * it could be text with many low-frequency hanzi
                 */
                return LOW_FREQ_HANZI_TEXT;
            }

            return (percent > maxPartialMessTextPercent) ?
                    TOTAL_MESS_TEXT : PARTIAL_MESS_TEXT;
        }

        return NOMAL_HANZI_TEXT;
    }

    /**
     * Compute the confidence of text to be normal Hanzi text
     * 
     * @param   text   text to be computed
     * @return  a value of type <code>float</code> representing confidence
     *          or UNDECIDABLE_CONFIDENCE,if the confidence cannot be computed
     * @see     MessyHanziDetector#UNDECIDABLE_CONFIDENCE
     * @see     MessyHanziDetector#getMinConfidence()
     */
    public float computeConfidence(String text) {
        char[] chars = text.toCharArray();
        return computeConfidence(chars, 0, chars.length);
    }

    /**
     * Compute the confidence of text to be normal Hanzi text
     * 
     * @param   buf   buffer of text to be computed
     * @return  a value of type <code>float</code> representing confidence
     *          or UNDECIDABLE_CONFIDENCE,if the confidence cannot be computed
     * @see     MessyHanziDetector#UNDECIDABLE_CONFIDENCE
     * @see     MessyHanziDetector#getMinConfidence()
     */
    public float computeConfidence(char[] buf) {
        return computeConfidence(buf, 0, buf.length);
    }

    /**
     * Compute the confidence of text to be normal Hanzi text
     * 
     * @param   buf   buffer of text to be computed
     * @param   offset   the initial offset of text
     * @param   count    the length of the text
     * @return  a value of type <code>float</code> representing confidence
     *          or UNDECIDABLE_CONFIDENCE,if the confidence cannot be computed
     * @see     MessyHanziDetector#UNDECIDABLE_CONFIDENCE
     * @see     MessyHanziDetector#getMinConfidence()
     * @exception IllegalArgumentException  if <code>offset</code> is
     *          negative, or <code>count</code> is negative.
     */
    public float computeConfidence(char[] buf, int offset, int count) {
        if (offset < 0) {
            throw new IllegalArgumentException(
                    "\"offset\" cannot be a negative!");
        }
        if (count < 0) {
            throw new IllegalArgumentException(
                    "\"count\" cannot be a negative!");
        }

        int badCharCount = 0, jpCharCount = 0, letterCount = 0;
        int hanziCount = 0, hanziInspected = 0, highFreqInspected = 0;

        Char c = new Char();
        int pos = offset;
        int end = (pos + count) > buf.length ? buf.length : (pos + count);
        while (pos < end) {
            /*
             * get block statistics
             * blocks are separated by line separators or paragraph separators
             */
            int badChar = 0, jpChar = 0, letter = 0;
            int hanzi = 0, highFreq = 0;
            for (boolean inBlock = true; inBlock && (pos < end); pos++) {
                char ch = buf[pos];
                int type = Character.getType(ch);
                switch (type) {
                    case Character.OTHER_LETTER:
                        if (ChnConstant.isChineseChar(ch)) {
                            ++hanzi;
                            c.set(ch);
                            if (highFreqHanzi.contains(c)) {
                                ++highFreq;
                            }
                        } else if (ChnConstant.isJapaneseChar(ch)) {
                            ++jpChar;
                        }
                        break;
                    case Character.UPPERCASE_LETTER:
                    case Character.LOWERCASE_LETTER:
                        ++letter;
                        break;
                    case Character.CONTROL:
                        if (ch == '\n') {
                            inBlock = false;
                        }
                        break;
                    case Character.LINE_SEPARATOR:
                    case Character.PARAGRAPH_SEPARATOR:
                        inBlock = false;
                        break;
                    case Character.PRIVATE_USE:
                        ++badChar;
                        break;
                    case Character.OTHER_SYMBOL:
                        if (ch == '\uFFFD') {
                            ++badChar;
                        }
                        break;
                    default:
                        ;
                }
            } /* for () */

            if (hanzi > 0) {
                hanziCount += hanzi;
                badCharCount += badChar;
                jpCharCount += jpChar;
                letterCount += letter;

                /* skip block with high confidence */
                if (highFreq < hanzi) {
                    hanziInspected += hanzi;
                    highFreqInspected += highFreq;
                }
            }
        } /* while (pos < end) */

        if (hanziCount == 0) {
            /* no hanzi, it is not Chinese text */
            return UNDECIDABLE_CONFIDENCE;
        }

        /* test whether it is Japanese text */
        float j2h = (float)jpCharCount / (float)hanziCount;
        if (j2h >= minRatioOfJpCharToHanzi) {
            /* Japanese text */
            return UNDECIDABLE_CONFIDENCE;
        }
        if (hanziInspected == 0) {
            /* no blocks with low confidence */
            return 1.0f;
        }

        /* compute confidence */
        float confidence = (float)highFreqInspected / (float)hanziInspected;
        float percent = (float)hanziInspected / (float)hanziCount;
        if (percent < minPartialMessTextPercent) {
            /*
             * to adjust confidence when the percent of possible messy text  
             * does not reach minMessyTextPercent
             */
            confidence = confidence * percent + (1 - percent);
        }

        /* test whether it is western text */
        float l2h = (float)letterCount / (float)hanziCount;
        if (l2h >= minRatioOfLetterToHanzi) {
            return confidence;
        }

        /*  messy-code text usually contains bad characters */
        if (confidence < minConfidence) {
            int minBadCharCount =
                (int)(minRatioOfBadCharToHanzi * hanziCount) + 1;
            if (badCharCount < minBadCharCount) {
                return minConfidence;
            } else {
                return confidence;
            }
        }

        return confidence;
    }

    /**
     * Load hanzi with high-frequency
     * 
     * @param   in   the input stream
     * @exception     IOException  if any I/O error occurs.
     */
    private static void loadHighFreqHanzi(InputStream in) throws IOException {
        BufferedReader reader = new BufferedReader(
                new InputStreamReader(
                        new BufferedInputStream(in), "UTF-8"));

        try {
              String line;
              while ((line = reader.readLine()) != null) {
                  if (line.startsWith("#") || (line.length() == 0)) {
                      continue;
                  }

                  String[] items = line.split("\t");
                  if ((items.length != 2)
                          || (items[0].length() != 1)) {
                      continue;
                  }

                  highFreqHanzi.add(new Char(items[0].charAt(0)));
              }
        } finally {
            reader.close();
        }
    }

    private static class Char {
        private char ch;

        public Char() {}

        public Char(char ch) {
            this.ch = ch;
        }

        public char get() {
            return ch;
        }

        public void set(char ch) {
            this.ch = ch;
        }

        public int hashCode() {
            return (int)ch;
        }

        public boolean equals(Object o) {
            if (!(o instanceof Char)) {
                return false;
            } else {
                return this.ch == ((Char)o).ch;
            }
        }
    }
}
