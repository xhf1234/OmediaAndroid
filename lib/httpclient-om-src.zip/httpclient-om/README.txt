README for HttpClient.

*******************************************
* 警告：请不要对该模块的代码进行reformat。*
*******************************************

* 模块来源

  - 该模块来自httpclient-release3.0.1(reversion 404763)。
  - 下载位置：http://www.uniontransit.com/apache/jakarta/commons/httpclient/source/commons-httpclient-3.0.1-src.tar.gz

* 导入SVN的部分以及怎样生成patch：

  - 目前导入svn的部分仅为上面的tar.gz文件解压缩以后的src/java部分。目前没有像svn导入src/test那些用于Test的部分。
  - build.xml和ivy.xml都是outfox代码，而不是从tar.gz中得到的。
  - 生成patch的办法：将svn check out出来的src/java拷贝一份（并删除.svn目录：rm -rf `find src/java -name .svn`），将tar.gz里面的src/java拷贝另外一份。执行：diff -ruN tar-gz/src/java svn-co/src/java > patch.diff

* 修改日志：

0. 2005-?: 让它能够接受我们直接传IP进去，并不去请求dns。
1. 2006-?: 修正了关于cookie的bug。
2. 2006-?: 修正了跳转头部的编码问题。
3. 2006-12:实现了基于IP的连接复用，而此前实际上是基于host的连接复用。
4. 2007/1/2: (zl) 修正了少量javadoc的tag错误，整理了build.xml，补充了一点README.txt(关于如何比较patch)，修正了ivy.xml的dependency关系。
